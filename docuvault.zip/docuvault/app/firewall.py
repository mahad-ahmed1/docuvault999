"""
Application-layer firewall: WAF inspection, per-IP rate limiting (DDoS
mitigation), brute-force defences and automatic temporary IP banning.

Production note: this layer complements — never replaces — network-edge
controls (AWS WAF / Cloud Armor / Azure Front Door WAF / Cloudflare, ALB
rate rules, Shield). Implementing it in-process means the portal protects
itself even when deployed bare. State is in-memory per worker; production
should back it with Redis (same interface).
"""
from __future__ import annotations

import asyncio
import json
import re
import time
from collections import defaultdict, deque
from urllib.parse import unquote

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from . import config
from .db import SessionLocal, audit

# ---------------------------------------------------------------------------
# Tunables (mirrored in config.py for the admin UI)
# ---------------------------------------------------------------------------
RATE_GENERAL = config.RATE_LIMIT_PER_IP_PER_MIN        # all requests / IP / min
RATE_LOGIN = config.LOGIN_RATE_LIMIT_PER_IP_PER_MIN    # login attempts / IP / min
RATE_ASK = config.ASK_RATE_LIMIT_PER_IP_PER_MIN        # AI queries / IP / min
RATE_UPLOAD = config.UPLOAD_RATE_LIMIT_PER_IP_PER_MIN  # uploads / IP / min
VIOLATIONS_TO_BAN = config.WAF_VIOLATIONS_TO_BAN       # within window -> ban
VIOLATION_WINDOW = config.WAF_VIOLATION_WINDOW_S
BAN_SECONDS = config.WAF_BAN_SECONDS
MAX_JSON_BODY = 1_000_000          # inspect JSON bodies up to 1 MB
MAX_TRACKED_IPS = 10_000           # memory cap for per-IP buckets
GLOBAL_CONCURRENCY = 64            # load shedding for request floods
SWEEP_INTERVAL = 30

# ---------------------------------------------------------------------------
# Signature rules (high-confidence only, to avoid blocking legitimate users)
# ---------------------------------------------------------------------------
SQLI_RULES = [
    (r"union[\s/\*+]+select", "SQLi: UNION SELECT"),
    (r"\bor\s+1\s*=\s*1\b", "SQLi: OR 1=1"),
    (r"\bor\s+'[^']*'\s*=\s*'", "SQLi: OR 'x'='x'"),
    (r";\s*drop\s+table", "SQLi: DROP TABLE"),
    (r";\s*delete\s+from", "SQLi: DELETE FROM"),
    (r";\s*update\s+\w+\s+set", "SQLi: UPDATE SET"),
    (r"\bwaitfor\s+delay\b", "SQLi: WAITFOR DELAY"),
    (r"\bsleep\s*\(", "SQLi: SLEEP()"),
    (r"\bbenchmark\s*\(", "SQLi: BENCHMARK()"),
    (r"\bload_file\s*\(", "SQLi: LOAD_FILE()"),
    (r"\bextractvalue\s*\(", "SQLi: EXTRACTVALUE()"),
    (r"\bupdatexml\s*\(", "SQLi: UPDATEXML()"),
    (r"information_schema\.", "SQLi: information_schema"),
    (r"\bxp_cmdshell\b", "SQLi: xp_cmdshell"),
    (r"'\s*;\s*--", "SQLi: quote-semicolon-dash"),
]
XSS_RULES = [
    (r"<\s*script", "XSS: <script>"),
    (r"javascript\s*:", "XSS: javascript: URI"),
    (r"\bonerror\s*=", "XSS: onerror handler"),
    (r"\bonload\s*=", "XSS: onload handler"),
]
TRAVERSAL_RULES = [
    ("../", "Traversal: dot-dot-slash"),
    ("..\\", "Traversal: dot-dot-backslash"),
    ("/etc/passwd", "Traversal: /etc/passwd"),
    ("/etc/shadow", "Traversal: /etc/shadow"),
    ("/proc/self", "Traversal: /proc/self"),
    ("c:\\windows", "Traversal: win path"),
]
# Paths that never exist in this app — hitting them means it is a scanner.
SCAN_PATHS = [".php", ".asp", ".jsp", ".env", ".git", ".sql", ".bak", ".ini",
              ".conf", ".yaml", ".ssh", "id_rsa", "wp-admin", "wp-login",
              "wp-content", "phpmyadmin", "xmlrpc.php", ".aws", ".docker",
              "config.json", "web.config", ".DS_Store"]
SCAN_UA = ["sqlmap", "nikto", "nmap", "masscan", "dirbuster", "gobuster",
           "wfuzz", "ffuf", "hydra", "acunetix", "nessus", "w3af",
           "arachni", "wpscan", "burp", "burpsuite", "zaproxy", "owasp zap"]
# Endpoint honeypots: no legitimate client or UI code ever references these.
HONEYPOT_PATHS = {"/api/debug", "/api/internal", "/api/test", "/api/admin/secret",
                  "/api/config", "/api/users/all"}
# Proxy-tool probes: header manipulation, CRLF, template/SSTI, Log4Shell,
# cloud-metadata SSRF (Burp Scanner / Tailored favorites).
EVASION_RULES = [
    ("${jndi:", "Log4Shell probe"),
    ("{{", "Template injection probe"),
    ("}}", "Template injection probe"),
    ("<%=", "SSTI probe"),
    ("%0d", "CRLF injection"),
    ("%0a", "CRLF injection"),
    ("\x0d", "CRLF injection"),
    ("\x0a", "CRLF injection"),
    ("169.254.169.254", "Cloud metadata SSRF probe"),
    ("metadata.google.internal", "Cloud metadata SSRF probe"),
]
CRLF_CHARS = ("\r", "\n")  # real CR/LF after percent-decoding
# Body keys never content-scanned (legitimate secrets may contain odd chars).
UNSCANNED_KEYS = {"password"}

_SQLI_RE = [(re.compile(p, re.I), n) for p, n in SQLI_RULES]
_XSS_RE = [(re.compile(p, re.I), n) for p, n in XSS_RULES]


class Firewall:
    """In-memory state: sliding windows, violation scores, bans, events."""

    def __init__(self) -> None:
        self.general: dict[str, deque] = defaultdict(deque)
        self.login: dict[str, deque] = defaultdict(deque)
        self.ask: dict[str, deque] = defaultdict(deque)
        self.upload: dict[str, deque] = defaultdict(deque)
        self.violations: dict[str, deque] = defaultdict(deque)
        self.rate429: dict[str, deque] = defaultdict(deque)   # 429 timestamps
        self.bans: dict[str, float] = {}
        self.last_seen: dict[str, float] = {}
        self.events: deque = deque(maxlen=200)
        self.last_sweep = 0.0
        self.stats = {"waf_blocked": 0, "rate_limited": 0, "bans_issued": 0,
                      "scanner_blocked": 0}

    # -- housekeeping -------------------------------------------------------
    def sweep(self, now: float) -> None:
        if now - self.last_sweep < SWEEP_INTERVAL:
            return
        self.last_sweep = now
        cutoff_v = now - VIOLATION_WINDOW
        cutoff_r = now - 120
        for bucket in (self.general, self.login, self.ask, self.upload,
                       self.violations):
            for ip in list(bucket.keys()):
                dq = bucket[ip]
                while dq and dq[0] < cutoff_r:
                    dq.popleft()
                if not dq:
                    del bucket[ip]
        for ip in list(self.bans.keys()):
            if self.bans[ip] < now:
                del self.bans[ip]
        for ip in list(self.last_seen.keys()):
            if self.last_seen[ip] < now - 600:
                del self.last_seen[ip]
        # hard memory cap
        if len(self.general) > MAX_TRACKED_IPS:
            oldest = sorted(self.general.keys(), key=lambda i: self.last_seen.get(i, 0))[:1000]
            for ip in oldest:
                self.general.pop(ip, None)

    # -- sliding window limiter ---------------------------------------------
    def hit(self, bucket: dict, ip: str, limit: int, now: float) -> tuple[bool, int]:
        dq = bucket[ip]
        while dq and dq[0] < now - 60:
            dq.popleft()
        if len(dq) >= limit:
            return False, 0
        dq.append(now)
        self.last_seen[ip] = now
        return True, max(0, limit - len(dq))

    # -- violations & bans ----------------------------------------------------
    def violation(self, ip: str, rule: str, path: str, now: float) -> None:
        self.stats["waf_blocked"] += 1
        dq = self.violations[ip]
        while dq and dq[0] < now - VIOLATION_WINDOW:
            dq.popleft()
        dq.append(now)
        self.events.appendleft({"ts": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()),
                                "ip": ip, "rule": rule, "path": path[:120]})
        self._audit(ip, rule, path)
        if len(dq) >= VIOLATIONS_TO_BAN:
            self.bans[ip] = now + BAN_SECONDS
            self.stats["bans_issued"] += 1
            self.events.appendleft({"ts": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()),
                                    "ip": ip, "rule": f"IP BANNED {BAN_SECONDS // 60} min "
                                                      f"({len(dq)} violations)", "path": "-"})
            self._audit(ip, f"AUTO-BAN ({len(dq)} violations)", path)

    def _audit(self, ip: str, rule: str, path: str) -> None:
        try:
            db = SessionLocal()
            audit(db, None, "WAF_BLOCK", target=path[:120], detail=rule, ip=ip)
            db.close()
        except Exception:  # noqa: BLE001 — logging must never break the wall
            pass

    def note_rate_limited(self, ip: str, now: float) -> None:
        """Repeated 429s (Intruder-style persistence) escalate to a short ban."""
        dq = self.rate429[ip]
        while dq and dq[0] < now - 60:
            dq.popleft()
        dq.append(now)
        if len(dq) >= config.RATE_LIMIT_ESCALATION_BAN:
            self.bans[ip] = now + config.RATE_LIMIT_ESCALATION_SECONDS
            self.stats["bans_issued"] += 1
            self.events.appendleft({"ts": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()),
                                    "ip": ip, "rule": f"AUTO-BAN: persistent rate-limit abuse "
                                                       f"({len(dq)}x 429/min)", "path": "-"})
            self._audit(ip, f"AUTO-BAN ({len(dq)}x 429 in 60s)", "-")

    def is_banned(self, ip: str, now: float) -> float:
        until = self.bans.get(ip)
        if until and until > now:
            return until
        if until:
            del self.bans[ip]
        return 0.0

    def overview(self) -> dict:
        now = time.time()
        return {
            "stats": dict(self.stats),
            "banned_now": [{"ip": ip, "expires_in_s": int(until - now)}
                           for ip, until in self.bans.items() if until > now],
            "tracked_ips": len(self.general) + len(self.login),
            "recent_events": list(self.events)[:30],
            "limits": {"general_per_min": RATE_GENERAL, "login_per_min": RATE_LOGIN,
                       "ask_per_min": RATE_ASK, "upload_per_min": RATE_UPLOAD,
                       "ban_threshold": VIOLATIONS_TO_BAN, "ban_minutes": BAN_SECONDS // 60},
        }


firewall = Firewall()
_semaphore: asyncio.Semaphore | None = None


def _sem() -> asyncio.Semaphore:
    global _semaphore
    if _semaphore is None:
        _semaphore = asyncio.Semaphore(GLOBAL_CONCURRENCY)
    return _semaphore


def _scan_value(value: str) -> str | None:
    for rx, name in _SQLI_RE + _XSS_RE:
        if rx.search(value):
            return name
    return None


def _flatten(data, key_hint: str = "", out: list | None = None) -> list:
    if out is None:
        out = []
    if isinstance(data, dict):
        for k, v in data.items():
            out.extend(_flatten(v, str(k)))
    elif isinstance(data, list):
        for v in data:
            out.extend(_flatten(v, key_hint))
    elif isinstance(data, str):
        if key_hint.lower() not in UNSCANNED_KEYS:
            out.append(data)
    return out


class FirewallMiddleware(BaseHTTPMiddleware):
    """Outermost middleware: inspect and rate-limit every request."""

    async def dispatch(self, request, call_next):
        now = time.time()
        firewall.sweep(now)

        # IP resolution: never trust client-supplied forwarding headers unless
        # explicitly deployed behind a trusted proxy — Burp Intruder would
        # otherwise rotate X-Forwarded-For values to dodge bans/limits.
        if config.TRUST_PROXY_XFF:
            fwd = request.headers.get("x-forwarded-for", "")
            ip = fwd.split(",")[-1].strip() if fwd else (
                request.client.host if request.client else "?")
        else:
            ip = request.client.host if request.client else "?"
        path = request.url.path
        decoded = unquote(unquote(path)).lower()

        def deny(status: int, detail: str, retry_after: int | None = None) -> JSONResponse:
            headers = {}
            origin = request.headers.get("origin")
            if origin:  # keep blocked responses readable by the sandboxed preview
                headers["Access-Control-Allow-Origin"] = origin
                headers["Access-Control-Allow-Headers"] = "Content-Type, X-Session-ID, X-CSRF-Token"
            if retry_after:
                headers["Retry-After"] = str(retry_after)
            return JSONResponse({"detail": detail}, status_code=status, headers=headers)

        # 0) ban list — /api/admin/firewall/* stays reachable so a signed-in
        # admin can clear false-positive bans (auth is still enforced there).
        until = firewall.is_banned(ip, now)
        if until and not path.startswith("/api/admin/firewall"):
            return deny(403, "Your IP address has been temporarily blocked by the firewall "
                             "due to repeated malicious requests.", retry_after=int(until - now))

        # 1) known scanner user-agents
        ua = request.headers.get("user-agent", "").lower()
        if any(tool in ua for tool in SCAN_UA):
            firewall.stats["scanner_blocked"] += 1
            firewall.violation(ip, f"Scanner user-agent: {ua[:40]}", path, now)
            return deny(403, "Request blocked by firewall (known attack tooling).")

        # 1b) honeypot endpoints (and their subpaths): high-severity violation
        if any(path == h or path.startswith(h + "/") for h in HONEYPOT_PATHS):
            firewall.violation(ip, "Honeypot endpoint probe", path, now)
            return deny(404, "Not found.")  # do not reveal it is a trap

        # 1c) proxy-tool evasion probes across path + query, raw (wire form,
        # incl. percent-encoding that uvicorn strips from `path`) and decoded
        raw_wire = (request.scope.get("raw_path", b"") or b"").decode("latin-1", "ignore")
        rawline = path + "?" + (request.url.query or "") + " " + raw_wire
        decoded = unquote(rawline)
        referer = request.headers.get("referer", "")
        for needle, rule in EVASION_RULES:
            if needle in rawline or needle in decoded or needle in referer:
                firewall.violation(ip, rule, path, now)
                return deny(403, "Request blocked by firewall (malformed request).")
        if any(c in decoded for c in CRLF_CHARS):
            firewall.violation(ip, "CRLF injection (decoded)", path, now)
            return deny(403, "Request blocked by firewall (malformed request).")

        # 1d) method-override headers are never honoured
        if "x-http-method-override" in {k.lower() for k in request.headers.keys()}:
            firewall.violation(ip, "Method override header", path, now)
            return deny(403, "Request blocked by firewall (method override).")

        # 2) path inspection: traversal, null bytes, scanner paths
        for needle, rule in TRAVERSAL_RULES:
            if needle in decoded:
                firewall.violation(ip, rule, path, now)
                return deny(403, "Request blocked by firewall (path traversal).")
        if "%00" in decoded:
            firewall.violation(ip, "Null byte in path", path, now)
            return deny(403, "Request blocked by firewall (null byte).")
        for needle in SCAN_PATHS:
            if needle in decoded:
                firewall.stats["scanner_blocked"] += 1
                firewall.violation(ip, f"Scanner path probe (..{needle[-12:]}..)", path, now)
                return deny(403, "Request blocked by firewall (non-existent resource probing).")

        # 3) per-IP rate limits (DDoS / brute-force layer)
        limit = RATE_GENERAL
        bucket = firewall.general
        if path == "/api/login":
            limit, bucket = RATE_LOGIN, firewall.login
        elif path == "/api/ask":
            limit, bucket = RATE_ASK, firewall.ask
        elif path == "/api/documents/upload":
            limit, bucket = RATE_UPLOAD, firewall.upload
        allowed, remaining = firewall.hit(bucket, ip, limit, now)
        if not allowed:
            firewall.stats["rate_limited"] += 1
            firewall.note_rate_limited(ip, now)
            return deny(429, "Rate limit exceeded. Slow down and retry in a minute.",
                        retry_after=60)

        # 4) body inspection (JSON payloads; uploads are size-checked only)
        ctype = request.headers.get("content-type", "")
        clen = int(request.headers.get("content-length", "0") or 0)
        if request.method in ("POST", "PUT", "PATCH"):
            if "application/json" in ctype and clen <= MAX_JSON_BODY:
                body = await request.body()

                async def replay():
                    return {"type": "http.request", "body": body, "more_body": False}

                request._receive = replay  # noqa: SLF001 — let the route re-read the body
                if body:
                    try:
                        data = json.loads(body)
                        for value in _flatten(data):
                            rule = _scan_value(value)
                            if rule:
                                firewall.violation(ip, rule, path, now)
                                return deny(403, f"Request blocked by firewall ({rule}).")
                    except (ValueError, UnicodeDecodeError):
                        pass
            elif clen > config.MAX_UPLOAD_MB * 1024 * 1024 + 65536:
                return deny(413, "Payload too large.", retry_after=60)

        # 5) load shedding under flood
        sem = _sem()
        if sem.locked():
            firewall.stats["rate_limited"] += 1
            return deny(503, "Server under heavy load — retry shortly.", retry_after=10)
        async with sem:
            response = await call_next(request)

        response.headers["X-RateLimit-Limit"] = str(limit)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        return response
