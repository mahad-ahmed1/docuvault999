"""
Security primitives: password policy & hashing (bcrypt), document-at-rest
encryption (Fernet / AES-CBC + HMAC-SHA256 with per-document keys derived via
HKDF-SHA256), CSRF tokens and session ids.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import re
import secrets
from functools import lru_cache

import bcrypt
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from . import config

# ---------------------------------------------------------------------------
# Password policy
# ---------------------------------------------------------------------------
COMMON_PASSWORDS = {
    "password", "password1", "password123", "123456", "12345678", "123456789",
    "qwerty", "qwerty123", "letmein", "welcome", "welcome1", "admin", "admin123",
    "iloveyou", "monkey", "dragon", "football", "abc123", "111111", "000000",
    "changeme", "meridian", "meridian123", "summer2026", "winter2026", "spring2026",
    "company123", "pakistan123", "karachi123",
}

MIN_LEN = 10
MAX_LEN = 64


def validate_password(password: str, username: str = "") -> tuple[bool, list[str]]:
    """Enforce the corporate password policy. Returns (ok, list_of_problems)."""
    problems: list[str] = []
    if len(password) < MIN_LEN:
        problems.append(f"Must be at least {MIN_LEN} characters long.")
    if len(password) > MAX_LEN:
        problems.append(f"Must be at most {MAX_LEN} characters long.")
    if not re.search(r"[A-Z]", password):
        problems.append("Must contain an uppercase letter.")
    if not re.search(r"[a-z]", password):
        problems.append("Must contain a lowercase letter.")
    if not re.search(r"[0-9]", password):
        problems.append("Must contain a digit.")
    if not re.search(r"[^A-Za-z0-9]", password):
        problems.append("Must contain a symbol.")
    if password.lower() in COMMON_PASSWORDS:
        problems.append("Too common (dictionary/breached list).")
    if username and username.lower().split(".")[0] in password.lower():
        problems.append("Must not contain your username.")
    return (len(problems) == 0, problems)


# Pre-computed bcrypt hash used to equalize login timing for unknown
# usernames — prevents user-enumeration via response-time analysis
# (a pro tester's classic finding: valid names take ~300 ms longer).
DUMMY_BCRYPT_HASH = bcrypt.hashpw(b"timing-equalizer-not-a-password",
                                  bcrypt.gensalt(rounds=config.BCRYPT_ROUNDS)).decode("ascii")


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=config.BCRYPT_ROUNDS)).decode("ascii")


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("ascii"))
    except ValueError:
        return False


# ---------------------------------------------------------------------------
# Session / CSRF secrets
# ---------------------------------------------------------------------------
def new_session_id() -> str:
    return secrets.token_urlsafe(32)


def new_csrf_token() -> str:
    return secrets.token_hex(32)


def constant_time_equals(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


# ---------------------------------------------------------------------------
# Document-at-rest encryption
#   master key  : 32 random bytes, stored 0600, provisionable via MASTER_KEY env
#   doc key     : HKDF-SHA256(master, salt=doc_id, info="docvault/file-enc")
#   payload     : Fernet (AES-128-CBC + HMAC-SHA256, random IV per message)
# ---------------------------------------------------------------------------
@lru_cache(maxsize=1)
def _master_key() -> bytes:
    import os
    env_key = os.getenv("MASTER_KEY", "").strip()
    if env_key:
        return base64.urlsafe_b64decode(env_key)
    if config.MASTER_KEY_PATH.exists():
        return base64.urlsafe_b64decode(config.MASTER_KEY_PATH.read_text().strip())
    config.ensure_dirs()
    raw = secrets.token_bytes(32)
    config.MASTER_KEY_PATH.write_text(base64.urlsafe_b64encode(raw).decode("ascii"))
    config.MASTER_KEY_PATH.chmod(0o600)
    return raw


def key_fingerprint() -> str:
    """Short, non-secret identifier of the master key (for the admin panel)."""
    fp = hashlib.sha256(_master_key()).hexdigest()[:16].upper()
    return "-".join(fp[i:i + 4] for i in range(0, 16, 4))


def _doc_key(doc_id: str) -> bytes:
    derived = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=doc_id.encode("utf-8"),
        info=b"docvault/file-enc/v1",
    ).derive(_master_key())
    return base64.urlsafe_b64encode(derived)


def encrypt_bytes(doc_id: str, plaintext: bytes) -> bytes:
    return Fernet(_doc_key(doc_id)).encrypt(plaintext)


def decrypt_bytes(doc_id: str, ciphertext: bytes) -> bytes:
    try:
        return Fernet(_doc_key(doc_id)).decrypt(ciphertext)
    except InvalidToken as exc:  # wrong key / tampering
        raise PermissionError("Decryption failed: integrity check did not pass.") from exc
