"""
Document processing pipeline:

    upload -> validate -> encrypt at rest -> parse text -> chunk ->
    embed -> upsert into the vector database (with clearance metadata)

Also provides index (re)building, which is triggered automatically when the
embedding space changes (e.g. a Gemini key is configured later on).
"""
from __future__ import annotations

import io
import re
from typing import List

from . import config
from .db import Document, SessionLocal, audit
from .embeddings import get_embedder
from .security import decrypt_bytes
from .vectorstore import get_store


# ---------------------------------------------------------------------------
# Text extraction
# ---------------------------------------------------------------------------
def parse_pdf(data: bytes) -> str:
    from pypdf import PdfReader
    reader = PdfReader(io.BytesIO(data))
    return "\n\n".join((page.extract_text() or "") for page in reader.pages)


def _docx_raw_text(data: bytes) -> list[str]:
    """Every <w:t> run in the package — catches text boxes, headers, footers,
    shapes: anything python-docx's object model does not expose."""
    import zipfile
    out: list[str] = []
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for name in z.namelist():
            if not name.endswith(".xml"):
                continue
            if not (name.startswith("word/") and
                    ("document" in name or "header" in name or "footer" in name
                     or "textbox" in name or "footnotes" in name or "endnotes" in name)):
                continue
            xml = z.read(name).decode("utf-8", errors="ignore")
            for para in xml.split("</w:p>"):
                runs = re.findall(r"<w:t[^>]*>([^<]*)</w:t>", para)
                line = "".join(runs).strip()
                if line:
                    out.append(line)
    return out


def parse_docx(data: bytes) -> str:
    import docx
    document = docx.Document(io.BytesIO(data))
    parts = [p.text for p in document.paragraphs if p.text.strip()]
    for table in document.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells if c.text.strip()]
            if cells:
                parts.append(" | ".join(cells))
    standard = "\n".join(parts)
    raw = _docx_raw_text(data)
    # If the object model missed content (text boxes etc.), merge it in.
    if raw and len(raw_text := "\n".join(raw)) > len(standard) + 200:
        seen, merged = set(), []
        for line in parts + raw:
            key = line.strip()
            if key and key not in seen:
                seen.add(key)
                merged.append(line)
        return "\n\n".join(merged)
    return standard if standard.strip() else "\n".join(raw)


def parse_plaintext(data: bytes) -> str:
    return data.decode("utf-8", errors="replace")


def extract_text(data: bytes, ext: str) -> str:
    if ext == ".pdf":
        return parse_pdf(data)
    if ext == ".docx":
        return parse_docx(data)
    return parse_plaintext(data)


# ---------------------------------------------------------------------------
# Chunking (paragraph-aware accumulation with overlap)
# ---------------------------------------------------------------------------
def chunk_text(text: str, size: int = config.CHUNK_SIZE, overlap: int = config.CHUNK_OVERLAP) -> List[str]:
    text = re.sub(r"[ \t]+", " ", text)
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks: List[str] = []
    buf = ""
    for para in paragraphs:
        if len(para) > size:
            if buf:
                chunks.append(buf)
                buf = buf[-overlap:] if overlap < len(buf) else ""
            for i in range(0, len(para), size - overlap):
                piece = para[i:i + size]
                if len(piece) > 40:
                    chunks.append(piece)
            buf = ""
            continue
        if len(buf) + len(para) + 2 <= size:
            buf = f"{buf}\n\n{para}" if buf else para
        else:
            chunks.append(buf)
            buf = (buf[-overlap:] if overlap < len(buf) else buf) + "\n\n" + para
    if buf.strip():
        chunks.append(buf)
    return [c.strip() for c in chunks if len(c.strip()) > 40]


# ---------------------------------------------------------------------------
# Index operations
# ---------------------------------------------------------------------------
def index_document(doc: Document, plaintext: str) -> tuple[int, int]:
    """Embed + store the chunks of one document.

    Returns (indexed_chunks, total_chunks). Chunks beyond MAX_CHUNKS_PER_DOC
    are stored in the encrypted file but not embedded (AI can't search them).
    """
    embedder = get_embedder()
    store = get_store()
    chunks = chunk_text(plaintext)
    total = len(chunks)
    if not chunks:
        return 0, 0
    truncated = chunks[: config.MAX_CHUNKS_PER_DOC]
    # Embed batch-by-batch so a quota hiccup only trims coverage instead of
    # failing the whole document (partial index > no index; a later admin
    # "Rebuild vector index" completes coverage when quota returns).
    import numpy as np

    all_vecs = []
    indexed = 0
    for i in range(0, len(truncated), 90):
        batch = truncated[i:i + 90]
        try:
            all_vecs.append(embedder.embed_documents(batch))
            indexed += len(batch)
        except Exception:  # noqa: BLE001 — keep what we have
            if indexed == 0:
                raise
            break
    vectors = all_vecs[0] if len(all_vecs) == 1 else np.vstack(all_vecs)
    truncated = truncated[:indexed]
    metas = [{
        "doc_id": doc.id,
        "doc_name": doc.original_name,
        "classification": int(doc.classification),
        "classification_label": config.CLASSIFICATION_LABELS.get(doc.classification, "Internal"),
        "chunk_index": i,
        "owner_id": doc.owner_id,
    } for i in range(len(truncated))]
    ids = [f"{doc.id}:{i}" for i in range(len(truncated))]
    store.delete_doc(doc.id)
    store.add(ids=ids, texts=truncated, embeddings=vectors, metadatas=metas, space=embedder.space)
    return indexed, total


def delete_document_vectors(doc_id: str) -> None:
    get_store().delete_doc(doc_id)


def reindex_all() -> dict:
    """Rebuild the whole vector index from the encrypted files on disk."""
    store = get_store()
    store.reset()
    db = SessionLocal()
    from .storage import get_file_store

    file_store = get_file_store()
    total_chunks, count = 0, 0
    try:
        for doc in db.query(Document).all():
            try:
                raw = decrypt_bytes(doc.id, file_store.get(doc.id, doc.storage_path))
                text = extract_text(raw, doc.ext)
                doc.chunk_count = index_document(doc, text)[0]
                total_chunks += doc.chunk_count
                count += 1
            except Exception as exc:  # noqa: BLE001
                audit(db, None, "REINDEX_ERROR", target=doc.original_name, detail=str(exc))
        db.commit()
    finally:
        db.close()
    return {"documents": count, "chunks": total_chunks}


def sync_index() -> dict:
    """Startup guard: rebuild the index if the embedding space changed,
    or if the index is empty while documents exist on disk."""
    embedder = get_embedder()
    store = get_store()
    db = SessionLocal()
    try:
        doc_count = db.query(Document).count()
    finally:
        db.close()
    if store.space and store.space != embedder.space:
        return {"rebuilt": True, "reason": f"embedding space changed {store.space!r} -> {embedder.space!r}",
                **reindex_all()}
    if store.count() == 0 and doc_count > 0:
        return {"rebuilt": True, "reason": "index empty while documents exist", **reindex_all()}
    return {"rebuilt": False, "chunks": store.count()}
