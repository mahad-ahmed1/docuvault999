"""
Administrator bootstrap.

- bootstrap(): guarantees an administrator account exists (safe to call at
  every startup; honours ADMIN_USERNAME / ADMIN_PASSWORD env vars).

The vault ships EMPTY by design — no sample users, no sample documents.
Additional accounts are created by the administrator under User
Administration; documents are uploaded through the portal. The end-to-end
smoke test (scripts/smoke.py) provisions its own throwaway accounts and
fixtures through the same admin API a real deployment would use.
"""
from __future__ import annotations

import os

from . import config
from .db import SessionLocal, User
from .security import hash_password, validate_password


def _mk_user(db, username: str, full_name: str, email: str, role: str, password: str,
             permissions: dict | None = None) -> User:
    ok, problems = validate_password(password, username)
    if not ok:
        raise ValueError(f"bootstrap password for {username} violates policy: {problems}")
    flags = {"can_upload": True, "can_ask": True, "can_download": True, "can_delete_own": True}
    clearance_override = None
    if permissions:
        clearance_override = permissions.get("clearance")
        flags.update({k: v for k, v in permissions.items() if k != "clearance"})
    user = User(
        username=username,
        full_name=full_name,
        email=email,
        role=role,
        clearance=clearance_override or config.ROLES[role],
        password_hash=hash_password(password),
        **flags,
    )
    db.add(user)
    db.commit()
    return user


def bootstrap() -> None:
    """Ensure at least one administrator exists."""
    db = SessionLocal()
    try:
        if db.query(User).count() == 0:
            username = os.getenv("ADMIN_USERNAME", "admin")
            password = os.getenv("ADMIN_PASSWORD", "Vault#Root2026")
            _mk_user(db, username, "System Administrator", f"{username}@meridian.example",
                     "ADMIN", password, None)
    finally:
        db.close()


if __name__ == "__main__":
    config.ensure_dirs()
    bootstrap()
    print("Bootstrap complete: administrator account ready "
          "(override with ADMIN_USERNAME / ADMIN_PASSWORD env vars).")
