/* ===================================================================
   DocuVault Enterprise — client application (vanilla JS, no CDN)
   All state flows through the JSON API with session-id + CSRF headers,
   so the app works identically in normal browsers and sandboxed
   preview frames where cookies may be unavailable.
   =================================================================== */
"use strict";

const BOOT = window.__BOOT__ || {};
const S = {
  sid: BOOT.session_id || "",
  csrf: BOOT.csrf_token || "",
  user: BOOT.user || null,
  expiresAt: BOOT.authenticated ? Date.now() + (BOOT.session_ttl || 1800) * 1000 : 0,
  gemini: !!BOOT.gemini_configured,
  messages: [],
  docs: [],
  view: "",
};

/* ---------------- helpers ---------------- */
const $ = (sel) => document.querySelector(sel);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g,
  (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

let toastTimer = null;
function toast(msg, kind) {
  let t = $("#toast");
  if (!t) { t = document.createElement("div"); t.id = "toast"; document.body.appendChild(t); }
  t.className = kind || "";
  t.textContent = msg;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.remove(), 4200);
}

/* Surface unexpected client errors visibly (enterprise apps fail loudly, not blankly). */
window.addEventListener("error", (ev) => {
  let box = document.getElementById("js-error-box");
  if (!box) {
    box = document.createElement("div");
    box.id = "js-error-box";
    box.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:99;background:#9c1f18;color:#fff;" +
      "font:12px/1.5 Consolas,monospace;padding:8px 14px;white-space:pre-wrap;";
    document.body.appendChild(box);
  }
  box.textContent = "Client error: " + (ev.message || "unknown") + (ev.filename ? " @ " + ev.filename + ":" + ev.lineno : "");
});

const badge = (label, cls) => `<span class="badge cls-${cls}">${esc(label)}</span>`;

async function api(path, opts = {}) {
  const { method = "GET", body = null, raw = false } = opts;
  const headers = { "X-Session-ID": S.sid, "X-CSRF-Token": S.csrf };
  if (body !== null) headers["Content-Type"] = "application/json";
  let res;
  try {
    res = await fetch(path, { method, headers, body: body !== null ? JSON.stringify(body) : undefined });
  } catch (networkErr) {
    // Server unreachable (restarting / offline). Clear, actionable message
    // instead of a bare browser "Failed to fetch".
    throw new Error("Cannot reach the portal — it may be restarting. Wait a few seconds and try again.");
  }
  const exp = res.headers.get("X-Session-Expires-In");
  if (exp) S.expiresAt = Date.now() + parseInt(exp, 10) * 1000;
  // A 401 from the login endpoint means bad credentials — show the server's
  // real message instead of the session-expired handler (anti-masking fix).
  if (res.status === 401 && !path.startsWith("/api/login")) {
    onSessionLost();
    throw new Error("Session expired — please sign in again.");
  }
  if (raw) return res;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.detail || res.statusText
      || "Request failed (HTTP " + res.status + "). If this persists, refresh the page or contact the administrator.");
    err.status = res.status;
    throw err;
  }
  return data;
}

/* ---------------- chrome (header / footer / banner) ---------------- */
function showChrome(on) {
  $("#topbar").classList.toggle("hidden", !on);
  $("#foot").classList.toggle("hidden", !on);
  $("#mode-banner").classList.toggle("hidden", !(on && !S.gemini && S.user));
}

function updateHeader() {
  if (!S.user) return;
  $("#user-chip").innerHTML =
    `<b>${esc(S.user.full_name)}</b> · ${esc(S.user.username)}<span class="role-tag">${esc(S.user.role)} · L${S.user.clearance}</span>`;
  $("#nav-admin").classList.toggle("hidden", !S.user.is_admin);
  $("#brand-org").textContent = BOOT.org || "";
  $("#foot-left").textContent = "DocuVault Enterprise v" + (BOOT.version || "") +
    " — Authorized use only. All activity is monitored and logged.";
  $("#foot-right").textContent = "© 2026 " + (BOOT.org || "") + " · Encryption: Fernet (AES + HMAC)";
  if (!S.gemini) {
    $("#mode-banner").innerHTML =
      "<b>Notice:</b>&nbsp;GEMINI_API_KEY is not configured — the assistant is running in " +
      "<b>Local Retrieval Mode</b> (hashed-TF-IDF embeddings with extractive answers). " +
      "Set GEMINI_API_KEY to enable Gemini generation.";
  } else {
    $("#mode-banner").classList.add("hidden");
  }
}

setInterval(() => {
  if (!S.user || !S.expiresAt) return;
  const left = Math.max(0, Math.floor((S.expiresAt - Date.now()) / 1000));
  const mm = String(Math.floor(left / 60)).padStart(2, "0");
  const ss = String(left % 60).padStart(2, "0");
  const el = $("#session-timer");
  if (el) el.textContent = "Session " + mm + ":" + ss;
  if (left <= 0) onSessionLost();
}, 1000);

function onSessionLost() {
  if (!S.user) return;
  S.user = null;
  toast("Session expired — please sign in again.", "err");
  location.hash = "";
  router();
}

/* ---------------- login view ---------------- */
function renderLogin() {
  showChrome(false);
  $("#main").innerHTML = `
  <div class="login-wrap">
    <div class="login-card">
      <div class="login-head">
        <svg class="shield" viewBox="0 0 24 24"><path fill="currentColor" d="M12 1l9 3.4v6.1c0 5.5-3.8 10.4-9 12.5-5.2-2.1-9-7-9-12.5V4.4L12 1z"/><path fill="#fff" d="M11 7h2v6h-2zm0 8h2v2h-2z"/></svg>
        <h1>DocuVault <span>Enterprise</span></h1>
        <p class="login-sub">Secure Document Search Portal — ${esc(BOOT.org || "")}</p>
      </div>
      <form id="login-form" autocomplete="off">
        <label for="lg-user">Username</label>
        <input id="lg-user" type="text" autocomplete="username" required autofocus>
        <label for="lg-pass">Password</label>
        <input id="lg-pass" type="password" autocomplete="current-password" required>
        <div id="lg-error" class="alert alert-error hidden" style="margin-top:12px"></div>
        <button class="btn btn-primary btn-block" id="lg-btn" type="submit">Sign In</button>
      </form>
      <div class="login-policy">Passwords must satisfy corporate policy. Accounts lock for 15 minutes
        after 5 failed attempts. All sign-in activity is audited.</div>
    </div>
    <p class="login-foot">© 2026 ${esc(BOOT.org || "")} · DocuVault Enterprise v${esc(BOOT.version || "")}</p>
  </div>`;
  $("#login-form").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const btn = $("#lg-btn"), err = $("#lg-error");
    btn.disabled = true; btn.textContent = "Signing in…"; err.classList.add("hidden");
    try {
      const data = await api("/api/login", {
        method: "POST",
        body: { username: $("#lg-user").value.trim(), password: $("#lg-pass").value, csrf_token: S.csrf },
      });
      S.sid = data.session_id; S.csrf = data.csrf_token; S.user = data.user;
      S.gemini = !!data.gemini_configured;
      S.expiresAt = Date.now() + data.expires_in * 1000;
      S.messages = [];
      toast("Welcome back, " + data.user.full_name + ".", "ok");
      location.hash = "#/dashboard";
      router();
    } catch (e) {
      err.textContent = e.message;
      err.classList.remove("hidden");
    } finally {
      btn.disabled = false; btn.textContent = "Sign In";
    }
  });
}

/* ---------------- dashboard ---------------- */
async function renderDashboard() {
  const d = await api("/api/dashboard");
  $("#main").innerHTML = `
  <div class="page">
    <div class="page-head">
      <h1>Dashboard</h1>
      <p>Welcome back, ${esc(S.user.full_name)}. Role: <b>${esc(S.user.role)}</b> ·
         Clearance: Level ${S.user.clearance} — ${esc(S.user.clearance_label)}</p>
    </div>
    ${d.gemini_configured ? "" : `<div class="alert alert-warn"><b>AI engine notice:</b> GEMINI_API_KEY is not configured.
      The portal is fully functional in <b>Local Retrieval Mode</b>; set the API key to enable Gemini-generated answers.</div>`}
    <div class="cards">
      <div class="card"><div class="label">Documents You Can Access</div><div class="value">${d.visible_documents}</div>
        <div class="sub">of ${d.total_documents} in the vault</div></div>
      <div class="card"><div class="label">Total Documents</div><div class="value">${d.total_documents}</div>
        <div class="sub">encrypted at rest</div></div>
      <div class="card"><div class="label">Your AI Queries (24h)</div><div class="value">${d.queries_24h}</div>
        <div class="sub">clearance-filtered RAG</div></div>
      <div class="card"><div class="label">AI Engine</div><div class="value" style="font-size:17px;line-height:1.3">
        ${d.gemini_configured ? "Gemini" : "Local Retrieval"}</div>
        <div class="sub">${d.gemini_configured ? "Gemini API connected" : "set GEMINI_API_KEY for Gemini"}</div></div>
    </div>
    <div class="grid-2">
      <section class="panel">
        <h2>Recently Uploaded Documents</h2>
        <table><thead><tr><th>Name</th><th>Class.</th><th>Owner</th></tr></thead><tbody>
          ${d.recent_documents.length ? d.recent_documents.map(x => `
            <tr><td class="doc-name">${esc(x.name)}</td>
                <td>${badge(x.classification_label, x.classification)}</td>
                <td class="muted">${esc(x.owner)}</td></tr>`).join("")
          : `<tr><td colspan="3" class="muted">No documents visible to you yet.</td></tr>`}
        </tbody></table>
      </section>
      <section class="panel">
        <h2>Your Recent Activity</h2>
        <ul class="activity">
          ${d.activity.length ? d.activity.map(a => `
            <li><span class="act-ts">${esc(a.ts)}</span><span class="act-action">${esc(a.action)}</span>
                <span>${esc(a.target)}${a.detail ? ` <span class="muted">— ${esc(a.detail)}</span>` : ""}</span></li>`).join("")
          : `<li><span class="muted">No activity recorded yet.</span></li>`}
        </ul>
      </section>
    </div>
  </div>`;
}

/* ---------------- documents ---------------- */
const CLASS_OPTS = { 1: "1 — Public", 2: "2 — Internal", 3: "3 — Confidential", 4: "4 — Restricted" };

async function renderDocuments() {
  const d = await api("/api/documents");
  S.docs = d.documents;
  const clsOptions = Object.entries(CLASS_OPTS)
    .filter(([k]) => Number(k) <= d.max_classification)
    .map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join("");
  $("#main").innerHTML = `
  <div class="page">
    <div class="page-head">
      <h1>Document Library</h1>
      <p>${d.documents.length} of ${d.total_documents} documents visible to you (clearance-filtered).
         Handling: this portal stores Confidential and Restricted material — all access is logged.</p>
    </div>
    ${S.user.perms && S.user.perms.upload ? `
    <section class="panel">
      <h2>Upload a Document</h2>
      <div class="upload-row">
        <input type="file" id="up-file">
        <select id="up-class">${clsOptions}</select>
        <button class="btn btn-primary" id="up-btn">Upload</button>
      </div>
      <div class="progress hidden" id="up-progress"><div class="bar" id="up-bar"></div></div>
      <p class="hint">Accepted types: ${esc(d.allowed_extensions.join(", "))} · Max ${d.max_upload_mb} MB ·
         Your role may classify up to <b>${esc(CLASS_OPTS[d.max_classification])}</b> ·
         Files are encrypted at rest before indexing.</p>
    </section>` : `<div class="alert alert-warn">Your account does not have permission to upload documents.</div>`}
    <section class="panel">
      <h2>Documents</h2>
      <div class="toolbar">
        <input type="text" id="doc-search" placeholder="Filter by name…">
        <select id="doc-filter"><option value="">All classifications</option>${clsOptions}</select>
      </div>
      <table>
        <thead><tr><th>Name</th><th>Classification</th><th>Owner</th><th class="num">Size</th>
          <th class="num">Chunks</th><th>Uploaded</th><th>Actions</th></tr></thead>
        <tbody id="doc-tbody"></tbody>
      </table>
    </section>
  </div>`;

  const redraw = () => {
    const q = $("#doc-search").value.toLowerCase();
    const f = $("#doc-filter").value;
    const rows = S.docs.filter(x =>
      (!q || x.name.toLowerCase().includes(q)) && (!f || String(x.classification) === f));
    $("#doc-tbody").innerHTML = rows.length ? rows.map(x => `
      <tr>
        <td class="doc-name">${esc(x.name)}</td>
        <td>${badge(x.classification_label, x.classification)}</td>
        <td class="muted">${esc(x.owner)}</td>
        <td class="num muted">${esc(x.size_human)}</td>
        <td class="num muted">${x.chunks}</td>
        <td class="muted">${esc(x.created_at)}</td>
        <td class="doc-actions">
          ${S.user.perms && S.user.perms.download ? `<button class="btn btn-outline btn-sm" data-dl="${x.id}">Download</button>` : ""}
          ${x.can_delete ? `<button class="btn btn-danger btn-sm" data-del="${x.id}">Delete</button>` : ""}
        </td>
      </tr>`).join("")
      : `<tr><td colspan="7" class="muted">No documents match the filter.</td></tr>`;
  };
  $("#doc-search").addEventListener("input", redraw);
  $("#doc-filter").addEventListener("change", redraw);
  $("#doc-tbody").addEventListener("click", (ev) => {
    const dl = ev.target.getAttribute("data-dl");
    const del = ev.target.getAttribute("data-del");
    if (dl) downloadDoc(S.docs.find(x => x.id === dl));
    if (del) deleteDoc(S.docs.find(x => x.id === del));
  });
  if ($("#up-btn")) {
    $("#up-btn").addEventListener("click", () => {
      const f = $("#up-file").files[0];
      if (!f) { toast("Choose a file to upload first.", "err"); return; }
      uploadDoc(f, $("#up-class").value);
    });
  }
  redraw();
}

function uploadDoc(file, classification) {
  const fd = new FormData();
  fd.append("file", file);
  fd.append("classification", classification);
  const xhr = new XMLHttpRequest();
  const bar = $("#up-progress"), fill = $("#up-bar"), btn = $("#up-btn");
  bar.classList.remove("hidden"); fill.style.width = "0%"; btn.disabled = true;
  xhr.open("POST", "/api/documents/upload");
  xhr.setRequestHeader("X-Session-ID", S.sid);
  xhr.setRequestHeader("X-CSRF-Token", S.csrf);
  xhr.upload.onprogress = (e) => { if (e.lengthComputable) fill.style.width = Math.round(e.loaded / e.total * 100) + "%"; };
  xhr.onload = () => {
    bar.classList.add("hidden"); btn.disabled = false;
    let data = {};
    try { data = JSON.parse(xhr.responseText); } catch (e) { /* ignore */ }
    if (xhr.status >= 200 && xhr.status < 300) {
      toast("Uploaded and indexed: " + data.name + " (" + data.chunks + " chunks)", "ok");
      renderDocuments().catch(() => {});
    } else {
      toast(data.detail || ("Upload failed (" + xhr.status + ")"), "err");
    }
  };
  xhr.onerror = () => { bar.classList.add("hidden"); btn.disabled = false; toast("Network error during upload.", "err"); };
  xhr.send(fd);
}

async function downloadDoc(doc) {
  try {
    const res = await api("/api/documents/" + doc.id + "/file", { raw: true });
    if (!res.ok) { const d = await res.json().catch(() => ({})); throw new Error(d.detail || "Download failed"); }
    const blob = await res.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = doc.name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 8000);
    toast("Decrypted download started: " + doc.name, "ok");
  } catch (e) { toast(e.message, "err"); }
}

async function deleteDoc(doc) {
  if (!confirm("Delete '" + doc.name + "' permanently? Encrypted file and index entries will be removed.")) return;
  try {
    await api("/api/documents/" + doc.id, { method: "DELETE" });
    toast("Deleted: " + doc.name, "ok");
    renderDocuments().catch(() => {});
  } catch (e) { toast(e.message, "err"); }
}

/* ---------------- assistant ---------------- */
const SUGGESTIONS = [
  "How many annual leave days do employees get?",
  "What are the password rules in the IT security policy?",
  "How do I report a security incident?",
  "Which expenses need pre-approval from my manager?",
];

async function renderAssistant() {
  if (!S.user.perms || !S.user.perms.ask) {
    $("#main").innerHTML = `
      <div class="page page-narrow">
        <div class="page-head"><h1>AI Assistant</h1></div>
        <div class="alert alert-warn">Your account does not have permission to use the AI assistant.
          Contact your administrator if you believe this is an error.</div>
      </div>`;
    return;
  }
  $("#main").innerHTML = `
  <div class="page page-narrow">
    <div class="page-head">
      <h1>AI Assistant</h1>
      <p>Answers are generated strictly from documents your clearance allows (Level ${S.user.clearance} —
         ${esc(S.user.clearance_label)}). Citation numbers [n] refer to the sources shown under each answer.</p>
    </div>
    ${S.gemini ? "" : `<div class="alert alert-warn"><b>Local Retrieval Mode.</b> GEMINI_API_KEY is not set, so answers are
      extracted directly from matching passages instead of being generated by Gemini.</div>`}
    <section class="panel chat-panel">
      <h2>Ask Your Documents</h2>
      <div id="chat-log" class="chat-log"></div>
      <div class="chat-suggest" id="chat-suggest">${SUGGESTIONS.map(s => `<button type="button" class="chip">${esc(s)}</button>`).join("")}</div>
      <form id="chat-form" class="chat-input">
        <textarea id="chat-text" rows="2" placeholder="Ask a question about your documents…"></textarea>
        <button class="btn btn-primary" id="chat-btn" type="submit">Ask</button>
      </form>
    </section>
  </div>`;

  const log = $("#chat-log");
  const draw = () => {
    log.innerHTML = S.messages.map(m => {
      if (m.role === "user")
        return `<div class="msg msg-user"><div class="msg-body">${esc(m.text)}</div></div>`;
      return `<div class="msg msg-ai">
        <div class="msg-head">DocuVault Assistant
          <span class="msg-meta">${esc(m.meta || "")}</span></div>
        <div class="msg-body">${m.error ? `<span style="color:var(--bad)">${esc(m.text)}</span>` : esc(m.text)}</div>
        ${m.sources ? `<div class="msg-sources">Sources: ${m.sources.map((s2, i) =>
          `<span class="cite-chip">[${i + 1}] ${esc(s2.doc_name)} ${badge(s2.classification_label, s2.classification)}</span>`).join("")
          || `<span class="muted">none</span>`}</div>` : ""}
      </div>`;
    }).join("") || `<p class="muted msg-typing">Ask a question to search your documents.</p>`;
    log.scrollTop = log.scrollHeight;
  };

  $("#chat-suggest").addEventListener("click", (ev) => {
    if (ev.target.classList.contains("chip")) {
      $("#chat-text").value = ev.target.textContent;
      $("#chat-form").requestSubmit();
    }
  });

  $("#chat-form").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const ta = $("#chat-text"), btn = $("#chat-btn");
    const q = ta.value.trim();
    if (!q) return;
    ta.value = ""; btn.disabled = true;
    S.messages.push({ role: "user", text: q });
    S.messages.push({ role: "ai", text: "Searching your documents…", typing: true });
    draw();
    try {
      const r = await api("/api/ask", { method: "POST", body: { question: q } });
      S.messages.pop();
      S.messages.push({
        role: "ai", text: r.answer, sources: r.sources,
        meta: `${r.passages_retrieved} passage${r.passages_retrieved === 1 ? "" : "s"} · ${r.elapsed_ms} ms · ` +
              (r.mode === "gemini" ? "Gemini" : r.mode === "gemini-general" ? "Gemini · general knowledge" :
              r.mode === "ai-unavailable" ? "AI unavailable" :
              r.mode === "gemini-cached" ? "Gemini (cached)" : r.mode === "no-context" ? "no matching context" :
               r.mode === "local-fallback" ? "local fallback" : "local retrieval") +
              (r.note ? " · " + r.note : ""),
      });
    } catch (e) {
      S.messages.pop();
      S.messages.push({ role: "ai", text: e.message, error: true });
    } finally {
      btn.disabled = false;
      draw();
    }
  });

  draw();
}

/* ---------------- admin ---------------- */
const PERM_DEFS = [
  ["upload", "Upload documents"],
  ["ask", "Use AI assistant"],
  ["download", "Download files"],
  ["delete_own", "Delete own documents"],
];
let editUserId = null;
let adminUsersCache = [];

function permBadges(perms) {
  return PERM_DEFS.map(([k, label]) => perms[k]
    ? `<span class="badge cls-1" title="${label}: allowed">${label.split(" ")[0]}</span>`
    : `<span class="badge" style="background:#f0f2f5;border-color:#d5dbe3;color:#8a97a6" title="${label}: denied">no ${label.split(" ")[0].toLowerCase()}</span>`
  ).join(" ");
}

function userFormHTML(u) {
  const isEdit = !!u;
  const role = u ? u.role : "EMPLOYEE";
  const clearance = u ? u.clearance : 2;
  const perms = u ? u.perms : { upload: true, ask: true, download: true, delete_own: true };
  const CLS = { 1: "Public", 2: "Internal", 3: "Confidential", 4: "Restricted" };
  return `
  <section class="panel">
    <h2>${isEdit ? `Edit User — ${esc(u.username)}` : "Add New User"}</h2>
    <form id="user-form" autocomplete="off">
      <div class="grid-2">
        <div>
          <label>Username</label>
          ${isEdit
            ? `<input type="text" value="${esc(u.username)}" disabled title="Usernames cannot be changed">`
            : `<input type="text" id="uf-username" required placeholder="e.g. jane.doe" maxlength="32">`}
          <label style="margin-top:12px">Full Name</label>
          <input type="text" id="uf-fullname" value="${u ? esc(u.full_name) : ""}" required maxlength="120">
          <label style="margin-top:12px">Email</label>
          <input type="text" id="uf-email" value="${u ? esc(u.email) : ""}" maxlength="190">
        </div>
        <div>
          <label>Role</label>
          <select id="uf-role" ${isEdit && u.username === S.user.username ? "disabled title='You cannot change your own role'" : ""}>
            ${["EMPLOYEE", "MANAGER", "ADMIN"].map(r => `<option ${r === role ? "selected" : ""}>${r}</option>`).join("")}
          </select>
          <label style="margin-top:12px">Clearance — what they can see</label>
          <select id="uf-clearance">
            ${[1, 2, 3, 4].map(c => `<option value="${c}" ${c === clearance ? "selected" : ""}>${c} — ${CLS[c]}</option>`).join("")}
          </select>
          <label style="margin-top:12px">${isEdit ? "New Password (leave blank to keep current)" : "Password"}</label>
          <input type="password" id="uf-password" ${isEdit ? "" : "required"} autocomplete="new-password"
                 placeholder="min 10 chars, upper+lower+digit+symbol">
        </div>
      </div>
      <label style="margin-top:16px">Account Permissions</label>
      <div style="display:flex;gap:18px;flex-wrap:wrap">
        ${PERM_DEFS.map(([k, label]) => `
          <label style="display:flex;align-items:center;gap:6px;text-transform:none;font-size:13px;letter-spacing:0;margin:0;font-weight:400;color:var(--ink)">
            <input type="checkbox" id="uf-perm-${k}" ${perms[k] ? "checked" : ""} style="width:auto"> ${label}
          </label>`).join("")}
      </div>
      ${isEdit ? `<label style="display:flex;align-items:center;gap:6px;text-transform:none;font-size:13px;letter-spacing:0;margin:12px 0 0;font-weight:400;color:var(--ink)">
        <input type="checkbox" id="uf-active" ${u.active ? "checked" : ""} style="width:auto"> Account active (sign-in allowed)
      </label>` : ""}
      <div class="actions">
        <button class="btn btn-primary" type="submit">${isEdit ? "Save Changes" : "Create User"}</button>
        ${isEdit ? `<button class="btn btn-outline" type="button" data-action="cancel-edit">Cancel</button>` : ""}
      </div>
      <p class="hint">Changes take effect immediately and are recorded in the audit log.
        Passwords must satisfy corporate policy (min 10 chars, upper, lower, digit, symbol).</p>
      <div id="uf-error" class="alert alert-error hidden" style="margin-top:10px"></div>
    </form>
  </section>`;
}

function wireUserForm() {
  const form = $("#user-form");
  if (!form) return;
  const roleSel = $("#uf-role"), clrSel = $("#uf-clearance");
  const defaults = { EMPLOYEE: 2, MANAGER: 3, ADMIN: 4 };
  if (!editUserId) {
    roleSel.addEventListener("change", () => { clrSel.value = String(defaults[roleSel.value] || 2); });
  }
  form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const err = $("#uf-error");
    err.classList.add("hidden");
    const perms = Object.fromEntries(PERM_DEFS.map(([k]) => [k, $("#uf-perm-" + k).checked]));
    try {
      if (editUserId) {
        const payload = { role: roleSel.value, clearance: Number(clrSel.value), permissions: perms };
        const activeBox = $("#uf-active");
        if (activeBox) payload.is_active = activeBox.checked;
        const pw = $("#uf-password").value;
        if (pw) payload.new_password = pw;
        await api("/api/admin/users/" + editUserId, { method: "PATCH", body: payload });
        toast("User updated.", "ok");
      } else {
        await api("/api/admin/users", {
          method: "POST",
          body: {
            username: $("#uf-username").value.trim(), full_name: $("#uf-fullname").value.trim(),
            email: $("#uf-email").value.trim(), role: roleSel.value, clearance: Number(clrSel.value),
            password: $("#uf-password").value, permissions: perms,
          },
        });
        toast("User created.", "ok");
      }
      editUserId = null;
      renderAdmin();
    } catch (e) {
      err.textContent = e.message;
      err.classList.remove("hidden");
    }
  });
}

async function renderAdmin() {
  let d;
  try { d = await api("/api/admin/overview"); }
  catch (e) {
    $("#main").innerHTML = `<div class="page"><div class="alert alert-error">${esc(e.message)}</div></div>`;
    return;
  }
  adminUsersCache = d.users;
  const editing = editUserId ? d.users.find(u => u.id === editUserId) : null;
  $("#main").innerHTML = `
  <div class="page">
    <div class="page-head"><h1>Administration</h1>
      <p>User administration, account permissions, firewall status and the audit trail.
         All administrative actions are recorded in the audit log.</p></div>
    ${userFormHTML(editing || null)}
    <div class="grid-2">
      <section class="panel">
        <h2>Users &amp; Permissions</h2>
        <table>
          <thead><tr><th>User</th><th>Role</th><th>Clear.</th><th>Permissions</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            ${d.users.map(u => `
            <tr>
              <td><b>${esc(u.username)}</b><br><span class="muted">${esc(u.full_name)}</span></td>
              <td>${esc(u.role)}</td>
              <td>L${u.clearance}${u.clearance_override ? ` <span class="badge cls-3" title="clearance set manually by an administrator">set</span>` : ""}</td>
              <td>${permBadges(u.perms)}</td>
              <td>${u.locked ? `<span class="badge cls-4">Locked ${esc(u.locked_until)}</span>`
                              : (u.active ? `<span class="badge cls-1">Active</span>` : `<span class="badge cls-3">Disabled</span>`)}
                  <div class="muted" style="font-size:11px">last: ${esc(u.last_login)}</div></td>
              <td class="doc-actions">
                <button class="btn btn-outline btn-sm" data-action="edit" data-id="${u.id}">Edit</button>
                ${u.locked ? `<button class="btn btn-outline btn-sm" data-action="unlock" data-id="${u.id}">Unlock</button>` : ""}
                ${u.username !== S.user.username ? (u.active
                  ? `<button class="btn btn-danger btn-sm" data-action="toggle-active" data-id="${u.id}">Disable</button>`
                  : `<button class="btn btn-outline btn-sm" data-action="toggle-active" data-id="${u.id}">Enable</button>`) : ""}
              </td>
            </tr>`).join("")}
          </tbody>
        </table>
      </section>
      <section class="panel">
        <h2>System Status</h2>
        <dl class="sys">
          <dt>Application</dt><dd>DocuVault v${esc(d.system.version)}</dd>
          <dt>AI engine</dt><dd>${d.system.gemini_configured ? "Gemini (" + esc(d.system.chat_model) + ")" : "Local Retrieval Mode"}</dd>
          <dt>Answer mode</dt><dd>${esc(d.system.answer_mode || "hybrid")}</dd>
          <dt>Vector database</dt><dd>${esc(d.system.vector_backend)}</dd>
          <dt>Document storage</dt><dd>${esc(d.system.storage_backend || "local disk")}</dd>
          <dt>Embedding space</dt><dd>${esc(d.system.embedding_space)}</dd>
          <dt>Documents / chunks</dt><dd>${d.system.total_documents} / ${d.system.total_chunks}</dd>
          <dt>Encryption</dt><dd>${esc(d.system.encryption)}</dd>
          <dt>Master key fingerprint</dt><dd>${esc(d.system.key_fingerprint)}</dd>
        </dl>
        <div class="actions">
          <button class="btn btn-outline" id="btn-reindex">Rebuild vector index</button>
        </div>
      </section>
    </div>
    <section class="panel">
      <h2>Firewall &amp; WAF</h2>
      <div class="cards" style="grid-template-columns:repeat(4,1fr);margin-bottom:12px">
        <div class="card"><div class="label">WAF blocks</div><div class="value">${d.security.stats.waf_blocked}</div></div>
        <div class="card"><div class="label">Rate-limited</div><div class="value">${d.security.stats.rate_limited}</div></div>
        <div class="card"><div class="label">Scanner blocks</div><div class="value">${d.security.stats.scanner_blocked}</div></div>
        <div class="card"><div class="label">Active IP bans</div><div class="value">${d.security.banned_now.length}</div></div>
      </div>
      <p class="hint">Limits per IP: ${d.security.limits.general_per_min} req/min general ·
         ${d.security.limits.login_per_min} logins/min · ${d.security.limits.ask_per_min} AI queries/min ·
         ${d.security.limits.upload_per_min} uploads/min · auto-ban after ${d.security.limits.ban_threshold}
         malicious requests for ${d.security.limits.ban_minutes} min · tracking ${d.security.tracked_ips} IPs.</p>
      ${d.security.banned_now.length ? `<table><thead><tr><th>Banned IP</th><th>Expires in</th></tr></thead><tbody>
        ${d.security.banned_now.map(b => `<tr><td class="mono">${esc(b.ip)}</td><td>${b.expires_in_s}s</td></tr>`).join("")}
      </tbody></table>` : `<p class="hint muted">No IPs currently banned.</p>`}
      ${d.security.recent_events.length ? `<table style="margin-top:10px"><thead><tr><th>Time (UTC)</th><th>IP</th><th>Rule</th><th>Path</th></tr></thead>
        <tbody>${d.security.recent_events.map(e2 => `
          <tr><td class="mono muted">${esc(e2.ts)}</td><td class="mono">${esc(e2.ip)}</td>
              <td><span class="badge cls-4">${esc(e2.rule)}</span></td>
              <td class="mono muted">${esc(e2.path)}</td></tr>`).join("")}</tbody></table>`
        : `<p class="hint muted">No firewall events recorded yet.</p>`}
    </section>
    <section class="panel">
      <h2>Audit Log — last 100 events</h2>
      <table><thead><tr><th>Time</th><th>User</th><th>Action</th><th>Target</th><th>Detail</th><th>IP</th></tr></thead>
      <tbody>${d.audit.map(a => `
        <tr><td class="mono muted">${esc(a.ts)}</td><td>${esc(a.username)}</td>
            <td><span class="act-action">${esc(a.action)}</span></td>
            <td>${esc(a.target)}</td><td class="muted">${esc(a.detail)}</td>
            <td class="mono muted">${esc(a.ip)}</td></tr>`).join("")}</tbody></table>
    </section>
  </div>`;
  wireUserForm();
  $("#btn-reindex").addEventListener("click", async (ev) => {
    ev.target.disabled = true; ev.target.textContent = "Rebuilding…";
    try {
      const r = await api("/api/admin/reindex", { method: "POST" });
      toast("Index rebuilt: " + r.documents + " documents, " + r.chunks + " chunks.", "ok");
    } catch (e) { toast(e.message, "err"); }
    renderAdmin();
  });
}

/* Delegated admin row actions (installed once, works across re-renders). */
document.addEventListener("click", async (ev) => {
  const el = ev.target.closest("[data-action]");
  if (!el || S.view !== "admin") return;
  const action = el.dataset.action, id = el.dataset.id;
  if (action === "edit") {
    editUserId = Number(id);
    router();
  } else if (action === "cancel-edit") {
    editUserId = null;
    router();
  } else if (action === "unlock") {
    try {
      await api("/api/admin/users/" + id + "/unlock", { method: "POST" });
      toast("User unlocked.", "ok");
      renderAdmin();
    } catch (e) { toast(e.message, "err"); }
  } else if (action === "toggle-active") {
    const u = adminUsersCache.find(x => String(x.id) === String(id));
    if (!u) return;
    if (u.active && !confirm("Deactivate '" + u.username + "'? The user will no longer be able to sign in.")) return;
    try {
      await api("/api/admin/users/" + id, { method: "PATCH", body: { is_active: !u.active } });
      toast(u.active ? "Account deactivated." : "Account activated.", "ok");
      renderAdmin();
    } catch (e) { toast(e.message, "err"); }
  }
});

/* ---------------- router ---------------- */
let renderSeq = 0;
async function routeTo(name) {
  const seq = ++renderSeq;
  try {
    if (name === "dashboard") await renderDashboard();
    else if (name === "documents") await renderDocuments();
    else if (name === "assistant") await renderAssistant();
    else if (name === "admin") await renderAdmin();
    else await renderDashboard();
  } catch (e) {
    if (seq === renderSeq) {
      $("#main").innerHTML = `<div class="page"><div class="alert alert-error">${esc(e.message)}</div></div>`;
    }
  }
}

function router() {
  if (!S.user) { renderLogin(); return; }
  showChrome(true);
  updateHeader();
  const name = (location.hash || "#/dashboard").replace("#/", "").split("?")[0] || "dashboard";
  S.view = name;
  document.querySelectorAll("#mainnav a").forEach(a =>
    a.classList.toggle("active", a.dataset.nav === name));
  routeTo(name);
}
window.addEventListener("hashchange", router);

$("#btn-signout").addEventListener("click", async () => {
  try { await api("/api/logout", { method: "POST" }); } catch (e) { /* session may already be gone */ }
  window.location.reload();
});

router();
