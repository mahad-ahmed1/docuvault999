"""
DocuVault Enterprise — FastAPI application.

Routes
------
GET    /                              single-page enterprise shell (login/auth state embedded)
POST   /api/login                     authenticate (lockout, generic errors, session rotation)
POST   /api/logout                    destroy session
GET    /api/me                        profile + system mode
GET    /api/dashboard                 stats, recent documents, recent activity
GET    /api/documents                 clearance-filtered document list
POST   /api/documents/upload          upload -> encrypt -> parse -> chunk -> embed -> index
GET    /api/documents/{id}/file       RBAC-checked decrypted download
DELETE /api/documents/{id}            owner/admin delete (vectors + file + row)
POST   /api/ask                       RAG question answering (clearance-filtered retrieval)
GET    /api/admin/overview            users, audit log, system status   (ADMIN)
POST   /api/admin/users/{id}/unlock   clear lockout                     (ADMIN)
POST   /api/admin/reindex             rebuild vector index              (ADMIN)
GET    /api/health                    liveness probe

Security middleware: CSP + hardening headers, CORS (needed by the sandboxed
preview; restrict in production), server-side sessions with CSRF tokens,
sliding expiry, HttpOnly cookies with X-Session-ID fallback for API clients.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from contextlib import asynccontextmanager
from datetime import timedelta
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session as DBSession
from starlette.middleware.base import BaseHTTPMiddleware

from . import ai, config, db, docproc
from .firewall import FirewallMiddleware, firewall
from .storage import get_file_store
from .db import AuditLog, AuthSession, Document, User, audit, get_db, new_id, utcnow
from .security import (DUMMY_BCRYPT_HASH, constant_time_equals, decrypt_bytes, encrypt_bytes,
                       hash_password, key_fingerprint, new_csrf_token, new_session_id,
                       validate_password, verify_password)
from .vectorstore import get_store

TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"
ASSETS_DIR = Path(__file__).resolve().parent / "assets"
CSS = (ASSETS_DIR / "app.css").read_text(encoding="utf-8")
JS = (ASSETS_DIR / "app.js").read_text(encoding="utf-8")

templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


@asynccontextmanager
async def lifespan(_app: FastAPI):
    config.ensure_dirs()
    db.init_db()
    from .security import _master_key  # ensure the encryption key exists first
    _master_key()
    from . import seed
    seed.bootstrap()
    stats = docproc.sync_index()
    print(f"[startup] DocuVault {config.VERSION} ready | index={stats} | "
          f"backend={get_store().name} | embeddings={get_embedder_space()} | "
          f"gemini={'ON' if config.GEMINI_API_KEY else 'OFF (local retrieval mode)'}")
    yield


app = FastAPI(title=config.APP_NAME, version=config.VERSION,
              docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)

# CORS: the sandboxed preview iframe runs from an opaque origin, so every API
# call is cross-origin there. Echo the Origin and expose the session header.
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=".*",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Session-Expires-In", "Content-Disposition"],
)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        # frame-ancestors is permissive for the hosted preview; lock to 'self' in production.
        response.headers["Content-Security-Policy"] = (
            "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
            "img-src data:; connect-src 'self'; base-uri 'none'"
        )
        expires_in = getattr(request.state, "session_expires_in", None)
        if expires_in is not None:
            response.headers["X-Session-Expires-In"] = str(int(expires_in))
        return response


app.add_middleware(SecurityHeadersMiddleware)
# Firewall runs outermost — it sees every request first.
app.add_middleware(FirewallMiddleware)


# ---------------------------------------------------------------------------
# Session handling
# ---------------------------------------------------------------------------
def client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for", "")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else ""


def _load_session(db: DBSession, sid: str | None) -> AuthSession | None:
    if not sid:
        return None
    session = db.get(AuthSession, sid)
    if session is None or session.expires_at < utcnow():
        return None
    return session


def _touch(session: AuthSession, db: DBSession) -> None:
    """Sliding expiry: extend when less than half the TTL remains."""
    remaining = (session.expires_at - utcnow()).total_seconds()
    ttl = config.SESSION_TTL_MINUTES * 60 if session.user_id else config.ANON_SESSION_TTL_MINUTES * 60
    if remaining < ttl / 2:
        session.expires_at = utcnow() + timedelta(seconds=ttl)
        db.commit()


def _new_session(db: DBSession, request: Request, user: User | None) -> AuthSession:
    session = AuthSession(
        id=new_session_id(),
        user_id=user.id if user else None,
        csrf_token=new_csrf_token(),
        ip_address=client_ip(request),
        user_agent=request.headers.get("user-agent", "")[:255],
        expires_at=utcnow() + timedelta(
            minutes=config.SESSION_TTL_MINUTES if user else config.ANON_SESSION_TTL_MINUTES),
    )
    db.add(session)
    db.commit()
    return session


def _require_api_user(request: Request, db: DBSession = Depends(get_db)) -> User:
    """Dependency: authenticated user + CSRF verification on unsafe methods."""
    sid = request.headers.get("x-session-id") or request.cookies.get(config.SESSION_COOKIE)
    session = _load_session(db, sid)
    if session is None or session.user_id is None:
        raise HTTPException(401, "Not authenticated.")
    user = db.get(User, session.user_id)
    if user is None or not user.is_active:
        raise HTTPException(401, "Not authenticated.")
    # Session binding: a session is only valid from the browser signature it
    # was created with — stolen-cookie replay from Burp Repeater is rejected.
    ua_now = request.headers.get("user-agent", "")[:255]
    if session.user_agent and ua_now and session.user_agent != ua_now:
        audit(db, user, "SESSION_UA_MISMATCH", target=user.username, ip=client_ip(request))
        raise HTTPException(401, "Session validation failed.")
    _check_origin(request)
    _touch(session, db)
    request.state.session = session
    request.state.session_expires_in = max(0, (session.expires_at - utcnow()).total_seconds())
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        token = request.headers.get("x-csrf-token", "")
        if not token or not constant_time_equals(token, session.csrf_token):
            raise HTTPException(403, "CSRF token missing or invalid.")
    return user


def _require_admin(user: User = Depends(_require_api_user)) -> User:
    if user.role != "ADMIN":
        raise HTTPException(403, "Administrator privileges required.")
    return user


DOC_ID_RE = re.compile(r"^[0-9a-f]{32}$")


def strict_payload(payload: dict, allowed: set[str], request: Request, label: str) -> None:
    """Mass-assignment / parameter-tampering shield (Burp Repeater favourite):
    JSON bodies may contain only documented fields; anything else is rejected
    and scored by the firewall."""
    extra = set(map(str, payload.keys())) - allowed
    if extra:
        raise HTTPException(400, "Request contains unexpected fields.")


def _check_origin(request: Request) -> None:
    """Reject cross-site state-changing requests when Origin is present.
    'null' (sandboxed iframe / sandboxed pages) is accepted; a concrete
    origin that does not match the request host is an attack signal."""
    origin = request.headers.get("origin")
    if not origin or origin == "null":
        return
    host = request.headers.get("host", "")
    try:
        from urllib.parse import urlsplit
        o = urlsplit(origin)
        if o.netloc and o.netloc != host:
            firewall.violation(client_ip(request), f"Cross-origin write attempt ({o.netloc[:60]})",
                               request.url.path, time.time())
            raise HTTPException(403, "Cross-origin request blocked.")
    except HTTPException:
        raise
    except Exception:  # noqa: BLE001 — malformed origin: reject outright
        raise HTTPException(403, "Malformed Origin header.")


def _check_doc_id(doc_id: str) -> None:
    """Defense-in-depth: document ids are 32-char hex; anything else is a probe."""
    if not DOC_ID_RE.fullmatch(doc_id):
        raise HTTPException(404, "Document not found.")


def _visible_documents(db: DBSession, user: User) -> list[Document]:
    return (db.query(Document)
            .filter(Document.classification <= user.clearance)
            .order_by(Document.created_at.desc()).all())


def _doc_public(db: DBSession, doc: Document, user: User) -> dict:
    owner = db.get(User, doc.owner_id)
    return {
        "id": doc.id,
        "name": doc.original_name,
        "ext": doc.ext,
        "classification": doc.classification,
        "classification_label": config.CLASSIFICATION_LABELS.get(doc.classification, "Internal"),
        "owner": (owner.full_name or owner.username) if owner else "—",
        "size_bytes": doc.size_bytes,
        "size_human": f"{doc.size_bytes / 1024:.1f} KB" if doc.size_bytes < 1024 * 1024
                      else f"{doc.size_bytes / 1024 / 1024:.1f} MB",
        "chunks": doc.chunk_count,
        "created_at": doc.created_at.strftime("%Y-%m-%d %H:%M"),
        "can_delete": user.role == "ADMIN" or (doc.owner_id == user.id and user.can_delete_own),
    }


def get_embedder_space() -> str:
    from .embeddings import get_embedder
    return get_embedder().space


# ---------------------------------------------------------------------------
# Shell (single-page enterprise UI)
# ---------------------------------------------------------------------------
@app.get("/", response_class=HTMLResponse)
def shell(request: Request, db: DBSession = Depends(get_db)):
    session = _load_session(db, request.cookies.get(config.SESSION_COOKIE))
    user = None
    if session and session.user_id:
        candidate = db.get(User, session.user_id)
        if candidate and candidate.is_active:
            user = candidate
    if session is None:
        session = _new_session(db, request, None)
    elif user:
        _touch(session, db)

    boot = {
        "authenticated": user is not None,
        "user": user.public() if user else None,
        "session_id": session.id,
        "csrf_token": session.csrf_token,
        "gemini_configured": bool(config.GEMINI_API_KEY),
        "app_name": config.APP_NAME,
        "org": config.ORG_NAME,
        "version": config.VERSION,
        "session_ttl": config.SESSION_TTL_MINUTES * 60,
    }
    boot_json = json.dumps(boot).replace("</", "<\\/")
    response = templates.TemplateResponse(request=request, name="index.html", context={
        "css": CSS, "js": JS, "boot_json": boot_json,
        "app_name": config.APP_NAME, "org": config.ORG_NAME,
    })
    if request.cookies.get(config.SESSION_COOKIE) != session.id:
        response.set_cookie(
            config.SESSION_COOKIE, session.id,
            httponly=True, samesite="lax",
            secure=request.headers.get("x-forwarded-proto") == "https",
            max_age=config.ANON_SESSION_TTL_MINUTES * 60,
        )
    return response


# ---------------------------------------------------------------------------
# Auth API
# ---------------------------------------------------------------------------
@app.post("/api/login")
def api_login(request: Request, payload: dict, db: DBSession = Depends(get_db)):
    strict_payload(payload, {"username", "password", "csrf_token"}, request, "login")
    username = str(payload.get("username", "")).strip().lower()
    password = str(payload.get("password", ""))
    if not username or not password or len(password) > 1024:
        raise HTTPException(400, "Username and password are required.")

    sid = request.headers.get("x-session-id") or request.cookies.get(config.SESSION_COOKIE)
    session = _load_session(db, sid)
    if session is not None and session.user_id is None:
        # CSRF enforced on the pre-login session (always present via the UI).
        token = str(payload.get("csrf_token", "")) or request.headers.get("x-csrf-token", "")
        if not token or not constant_time_equals(token, session.csrf_token):
            raise HTTPException(403, "CSRF token missing or invalid.")

    user = db.query(User).filter_by(username=username).first()
    ip = client_ip(request)
    generic = "Invalid username or password."

    if user is None:
        verify_password(password, DUMMY_BCRYPT_HASH)  # equalize timing (anti-enumeration)
        audit(db, None, "LOGIN_FAILED", target=username or "(empty)", ip=ip)
        raise HTTPException(401, generic)

    if user.locked_until and user.locked_until > utcnow():
        audit(db, None, "LOGIN_LOCKED", target=username, ip=ip)
        raise HTTPException(401, generic)
    if not user.is_active:
        audit(db, None, "LOGIN_FAILED", target=username, detail="inactive account", ip=ip)
        raise HTTPException(401, generic)

    if verify_password(password, user.password_hash):
        # Success: rotate the session id (fixation defence) and reset counters.
        user.failed_logins = 0
        user.locked_until = None
        user.last_login_at = utcnow()
        db.commit()
        if session is not None:
            db.delete(session)
            db.commit()
        fresh = _new_session(db, request, user)
        audit(db, user, "LOGIN_SUCCESS", ip=ip)
        return {
            "session_id": fresh.id, "csrf_token": fresh.csrf_token, "user": user.public(),
            "expires_in": config.SESSION_TTL_MINUTES * 60,
            "gemini_configured": bool(config.GEMINI_API_KEY),
        }

    user.failed_logins = (user.failed_logins or 0) + 1
    if user.failed_logins >= config.MAX_FAILED_LOGINS:
        user.locked_until = utcnow() + timedelta(minutes=config.LOCKOUT_MINUTES)
    db.commit()
    audit(db, None, "LOGIN_FAILED", target=username, detail=f"attempt {user.failed_logins}", ip=ip)
    raise HTTPException(401, generic)


@app.post("/api/logout")
def api_logout(request: Request, user: User = Depends(_require_api_user),
               db: DBSession = Depends(get_db)):
    session: AuthSession = request.state.session
    db.delete(session)
    db.commit()
    audit(db, user, "LOGOUT", ip=client_ip(request))
    response = JSONResponse({"ok": True})
    response.delete_cookie(config.SESSION_COOKIE)
    return response


@app.get("/api/me")
def api_me(user: User = Depends(_require_api_user), db: DBSession = Depends(get_db)):
    store = get_store()
    visible = _visible_documents(db, user)
    return {
        "user": user.public(),
        "gemini_configured": bool(config.GEMINI_API_KEY),
        "answer_mode": config.ANSWER_MODE,
        "documents_visible": len(visible),
        "documents_total": db.query(Document).count(),
        "vector_backend": store.name,
        "embedding_space": get_embedder_space(),
        "key_fingerprint": key_fingerprint(),
    }


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@app.get("/api/dashboard")
def api_dashboard(user: User = Depends(_require_api_user), db: DBSession = Depends(get_db)):
    visible = _visible_documents(db, user)
    since = utcnow() - timedelta(hours=24)
    queries_24h = (db.query(AuditLog)
                   .filter(AuditLog.user_id == user.id,
                           AuditLog.action == "QUERY_ASKED",
                           AuditLog.ts >= since).count())
    activity = (db.query(AuditLog).filter(AuditLog.user_id == user.id)
                .order_by(AuditLog.ts.desc()).limit(8).all())
    return {
        "visible_documents": len(visible),
        "total_documents": db.query(Document).count(),
        "queries_24h": queries_24h,
        "last_login": user.last_login_at.strftime("%Y-%m-%d %H:%M") if user.last_login_at else "—",
        "gemini_configured": bool(config.GEMINI_API_KEY),
        "recent_documents": [_doc_public(db, d, user) for d in visible[:5]],
        "activity": [{"ts": a.ts.strftime("%Y-%m-%d %H:%M"), "action": a.action,
                      "target": a.target, "detail": a.detail} for a in activity],
    }


# ---------------------------------------------------------------------------
# Documents
# ---------------------------------------------------------------------------
@app.get("/api/documents")
def api_documents(user: User = Depends(_require_api_user), db: DBSession = Depends(get_db)):
    docs = _visible_documents(db, user)
    return {
        "documents": [_doc_public(db, d, user) for d in docs],
        "total_documents": db.query(Document).count(),
        "max_classification": config.ROLES[user.role],
        "classification_labels": config.CLASSIFICATION_LABELS,
        "allowed_extensions": sorted(config.ALLOWED_EXTENSIONS),
        "max_upload_mb": config.MAX_UPLOAD_MB,
    }


@app.post("/api/documents/upload")
def api_upload(request: Request,
               file: UploadFile = File(...),
               classification: int = Form(2),
               user: User = Depends(_require_api_user),
               db: DBSession = Depends(get_db)):
    ip = client_ip(request)
    if not user.can_upload:
        audit(db, user, "PERM_DENIED", target=file.filename or "", detail="upload", ip=ip)
        raise HTTPException(403, "Your account does not have permission to upload documents.")
    if classification not in config.CLASSIFICATION_LABELS:
        raise HTTPException(400, "Unknown classification level.")
    role_limit = config.ROLES[user.role]
    if classification > role_limit:
        audit(db, user, "UPLOAD_DENIED", target=file.filename or "",
              detail=f"classification {classification} above role limit", ip=ip)
        raise HTTPException(403, f"Your role may upload up to "
                                 f"'{config.CLASSIFICATION_LABELS[role_limit]}' classification.")

    original = Path(file.filename or "").name
    ext = Path(original).suffix.lower()
    if not original or ext not in config.ALLOWED_EXTENSIONS:
        raise HTTPException(415, "File type not allowed. Accepted: "
                                 + ", ".join(sorted(config.ALLOWED_EXTENSIONS)))
    original = (re.sub(r"[^\w.\- ()\[\]]", "_", original)[:120] or "document") + ("" if ext in original else ext)

    max_bytes = config.MAX_UPLOAD_MB * 1024 * 1024
    data = file.file.read(max_bytes + 1)
    if len(data) == 0:
        raise HTTPException(400, "Empty file.")
    if len(data) > max_bytes:
        raise HTTPException(413, f"File exceeds the {config.MAX_UPLOAD_MB} MB limit.")

    doc_id = new_id()
    try:
        text = docproc.extract_text(data, ext)
        if len(text.strip()) < 40:
            raise ValueError("No readable text content found.")
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(422, f"Could not extract text from this file ({exc}).")

    ciphertext = encrypt_bytes(doc_id, data)
    storage_path = get_file_store().put(doc_id, ciphertext)

    doc = Document(
        id=doc_id, original_name=original, ext=ext,
        mime=file.content_type or "application/octet-stream",
        classification=classification, owner_id=user.id,
        size_bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
        storage_path=storage_path,
    )
    db.add(doc)
    db.commit()
    try:
        indexed, total_chunks = docproc.index_document(doc, text)
        doc.chunk_count = indexed
        db.commit()
    except Exception as exc:  # noqa: BLE001 — a failed index must never 500 or orphan rows
        get_file_store().delete(doc.id, storage_path)
        try:
            docproc.delete_document_vectors(doc.id)
        except Exception:  # noqa: BLE001
            pass
        db.delete(doc)
        db.commit()
        audit(db, user, "UPLOAD_FAILED", target=original, detail=str(exc)[:200], ip=ip)
        msg = str(exc)
        if "429" in msg or "RESOURCE_EXHAUSTED" in msg or "quota" in msg.lower():
            raise HTTPException(503, "AI indexing is temporarily rate-limited (embedding quota). "
                                     "Your file was not stored — please retry in a minute.")
        raise HTTPException(422, f"Indexing failed ({type(exc).__name__}). "
                                 "The file was not stored — it may be corrupted or unreadable.")
    detail = f"class={config.CLASSIFICATION_LABELS[classification]}, chunks={doc.chunk_count}"
    if indexed < total_chunks:
        detail += f" (AI index capped at {config.MAX_CHUNKS_PER_DOC}; file fully stored)"
    audit(db, user, "DOC_UPLOAD", target=original, detail=detail, ip=ip)
    return _doc_public(db, doc, user)


@app.get("/api/documents/{doc_id}/file")
def api_download(request: Request, doc_id: str, user: User = Depends(_require_api_user),
                 db: DBSession = Depends(get_db)):
    _check_doc_id(doc_id)
    doc = db.get(Document, doc_id)
    if doc is None:
        raise HTTPException(404, "Document not found.")
    if doc.classification > user.clearance:
        audit(db, user, "ACCESS_DENIED", target=doc.original_name,
              detail="download above clearance", ip=client_ip(request))
        raise HTTPException(403, "This document is above your clearance level.")
    if not user.can_download:
        audit(db, user, "PERM_DENIED", target=doc.original_name, detail="download", ip=client_ip(request))
        raise HTTPException(403, "Your account does not have permission to download files.")
    try:
        data = decrypt_bytes(doc.id, get_file_store().get(doc.id, doc.storage_path))
    except (PermissionError, FileNotFoundError) as exc:
        raise HTTPException(500, "Stored file could not be decrypted.") from exc
    audit(db, user, "DOC_DOWNLOAD", target=doc.original_name, ip=client_ip(request))
    return Response(
        content=data,
        media_type=doc.mime or "application/octet-stream",
        headers={"Content-Disposition": f"attachment; filename=\"{doc.original_name}\""},
    )


@app.delete("/api/documents/{doc_id}")
def api_delete(request: Request, doc_id: str, user: User = Depends(_require_api_user),
               db: DBSession = Depends(get_db)):
    _check_doc_id(doc_id)
    doc = db.get(Document, doc_id)
    if doc is None:
        raise HTTPException(404, "Document not found.")
    if doc.classification > user.clearance:
        raise HTTPException(403, "This document is above your clearance level.")
    if user.role != "ADMIN":
        if doc.owner_id != user.id:
            raise HTTPException(403, "Only the owner or an administrator may delete a document.")
        if not user.can_delete_own:
            audit(db, user, "PERM_DENIED", target=doc.original_name, detail="delete", ip=client_ip(request))
            raise HTTPException(403, "Your account does not have permission to delete documents.")
    docproc.delete_document_vectors(doc.id)
    get_file_store().delete(doc.id, doc.storage_path)
    db.delete(doc)
    db.commit()
    audit(db, user, "DOC_DELETE", target=doc.original_name, ip=client_ip(request))
    return {"ok": True}


# ---------------------------------------------------------------------------
# RAG ask endpoint
# ---------------------------------------------------------------------------
@app.post("/api/ask")
def api_ask(request: Request, payload: dict,
            user: User = Depends(_require_api_user), db: DBSession = Depends(get_db)):
    strict_payload(payload, {"question"}, request, "ask")
    if not user.can_ask:
        audit(db, user, "PERM_DENIED", target="ai-assistant", ip=client_ip(request))
        raise HTTPException(403, "Your account does not have permission to use the AI assistant.")
    question = str(payload.get("question", "")).strip()
    if not question:
        raise HTTPException(400, "Please type a question.")
    if len(question) > 2000:
        raise HTTPException(400, "Question too long (2000 characters max).")
    if not ai.check_rate_limit(user.id):
        raise HTTPException(429, f"Rate limit: max {config.RATE_LIMIT_ASK_PER_MIN} questions per minute.")
    try:
        result = ai.answer_question(question, user)
    except Exception:  # noqa: BLE001 — final safety net: ask never returns a 500
        import traceback
        traceback.print_exc()
        result = {"answer": ai.NOT_FOUND, "sources": [], "mode": "no-context",
                  "note": "unexpected server error — safe refusal shown",
                  "passages_retrieved": 0, "elapsed_ms": 0}
    audit(db, user, "QUERY_ASKED", target=question[:120],
          detail=f"mode={result['mode']}, passages={result['passages_retrieved']}, "
                 f"{result['elapsed_ms']}ms", ip=client_ip(request))
    return result


# ---------------------------------------------------------------------------
# Admin
# ---------------------------------------------------------------------------
@app.get("/api/admin/overview")
def api_admin_overview(user: User = Depends(_require_admin), db: DBSession = Depends(get_db)):
    users = db.query(User).order_by(User.username).all()
    logs = db.query(AuditLog).order_by(AuditLog.ts.desc()).limit(100).all()
    store = get_store()
    now = utcnow()
    return {
        "users": [{
            "id": u.id, "username": u.username, "full_name": u.full_name, "role": u.role,
            "clearance": u.clearance,
            "clearance_label": config.CLASSIFICATION_LABELS.get(u.clearance, "?"),
            "is_active": u.is_active,
            "active": u.is_active,
            "perms": {"upload": u.can_upload, "ask": u.can_ask,
                      "download": u.can_download, "delete_own": u.can_delete_own},
            "clearance_override": u.clearance != config.ROLES.get(u.role, u.clearance),
            "failed_logins": u.failed_logins,
            "locked": bool(u.locked_until and u.locked_until > now),
            "locked_until": u.locked_until.strftime("%H:%M") if (u.locked_until and u.locked_until > now) else "",
            "last_login": u.last_login_at.strftime("%Y-%m-%d %H:%M") if u.last_login_at else "never",
        } for u in users],
        "audit": [{
            "ts": a.ts.strftime("%Y-%m-%d %H:%M:%S"), "username": a.username or "(anonymous)",
            "action": a.action, "target": a.target[:80], "detail": a.detail[:120], "ip": a.ip,
        } for a in logs],
        "security": firewall.overview(),
        "system": {
            "version": config.VERSION,
            "gemini_configured": bool(config.GEMINI_API_KEY),
            "answer_mode": config.ANSWER_MODE,
            "chat_model": config.GEMINI_CHAT_MODEL if config.GEMINI_API_KEY else "— (local retrieval mode)",
            "vector_backend": store.name,
            "storage_backend": f"{get_file_store().name} ({config.STORAGE_BACKEND})",
            "embedding_space": get_embedder_space(),
            "total_documents": db.query(Document).count(),
            "total_chunks": store.count(),
            "key_fingerprint": key_fingerprint(),
            "encryption": "Fernet (AES-128-CBC + HMAC-SHA256), per-document HKDF keys",
        },
    }


USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{2,31}$")


def _permissions_from(payload: dict) -> dict:
    perms = payload.get("permissions") or {}
    return {
        "can_upload": bool(perms.get("upload", True)),
        "can_ask": bool(perms.get("ask", True)),
        "can_download": bool(perms.get("download", True)),
        "can_delete_own": bool(perms.get("delete_own", True)),
    }


@app.post("/api/admin/firewall/unban")
def api_admin_firewall_unban(request: Request, payload: dict,
                             admin: User = Depends(_require_admin),
                             db: DBSession = Depends(get_db)):
    """Release a false-positive IP ban (escape hatch that works even while
    the admin's own IP is banned; authentication + CSRF still required)."""
    ip = str(payload.get("ip", "")).strip()
    if not ip:
        raise HTTPException(400, "ip is required.")
    removed = firewall.bans.pop(ip, None) is not None
    firewall.violations.pop(ip, None)
    firewall.rate429.pop(ip, None)
    audit(db, admin, "FIREWALL_UNBAN", target=ip,
          detail="removed" if removed else "was not banned", ip=client_ip(request))
    return {"ok": True, "removed": removed}


@app.post("/api/admin/users")
def api_admin_create_user(request: Request, payload: dict,
                          admin: User = Depends(_require_admin),
                          db: DBSession = Depends(get_db)):
    strict_payload(payload, {"username", "full_name", "email", "role", "clearance",
                             "password", "permissions"}, request, "user create")
    username = str(payload.get("username", "")).strip().lower()
    full_name = str(payload.get("full_name", "")).strip()[:120]
    email = str(payload.get("email", "")).strip()[:190]
    role = str(payload.get("role", "EMPLOYEE")).strip().upper()
    password = str(payload.get("password", ""))
    if not USERNAME_RE.fullmatch(username):
        raise HTTPException(400, "Username must be 3-32 characters: lowercase letters, digits, dots or dashes, starting with a letter or digit.")
    if role not in config.ROLES:
        raise HTTPException(400, "Unknown role.")
    try:
        clearance = int(payload.get("clearance") or config.ROLES[role])
    except (TypeError, ValueError):
        raise HTTPException(400, "Clearance must be 1-4.")
    if clearance not in config.CLASSIFICATION_LABELS:
        raise HTTPException(400, "Clearance must be 1-4.")
    ok, problems = validate_password(password, username)
    if not ok:
        raise HTTPException(400, "Password policy: " + " ".join(problems))
    if db.query(User).filter_by(username=username).first():
        raise HTTPException(409, "That username already exists.")
    user = User(username=username, full_name=full_name, email=email, role=role,
                clearance=clearance, password_hash=hash_password(password),
                **_permissions_from(payload))
    db.add(user)
    db.commit()
    perms = user.public()["perms"]
    audit(db, admin, "USER_CREATE", target=username,
          detail=f"role={role}, clearance={clearance}, upload={perms['upload']}, ask={perms['ask']}, "
                 f"download={perms['download']}, delete={perms['delete_own']}",
          ip=client_ip(request))
    return user.public()


@app.patch("/api/admin/users/{user_id}")
def api_admin_update_user(request: Request, user_id: int, payload: dict,
                          admin: User = Depends(_require_admin),
                          db: DBSession = Depends(get_db)):
    strict_payload(payload, {"role", "clearance", "permissions", "is_active", "new_password"},
                   request, "user update")
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(404, "User not found.")
    changes: list[str] = []
    if "role" in payload:
        role = str(payload["role"]).strip().upper()
        if role not in config.ROLES:
            raise HTTPException(400, "Unknown role.")
        if user.id == admin.id and role != "ADMIN":
            raise HTTPException(400, "You cannot change your own role.")
        user.role = role
        changes.append(f"role={role}")
    if "clearance" in payload:
        try:
            clearance = int(payload["clearance"])
        except (TypeError, ValueError):
            raise HTTPException(400, "Clearance must be 1-4.")
        if clearance not in config.CLASSIFICATION_LABELS:
            raise HTTPException(400, "Clearance must be 1-4.")
        user.clearance = clearance
        changes.append(f"clearance={clearance}")
    if "permissions" in payload:
        perms = _permissions_from(payload)
        for key, value in perms.items():
            setattr(user, key, value)
        changes.append("perms=" + ",".join(k[4:] for k, v in perms.items() if v) or "none")
    if "is_active" in payload:
        active = bool(payload["is_active"])
        if user.id == admin.id and not active:
            raise HTTPException(400, "You cannot deactivate your own account.")
        user.is_active = active
        changes.append("active=" + str(active))
    if "new_password" in payload and payload["new_password"]:
        ok, problems = validate_password(str(payload["new_password"]), user.username)
        if not ok:
            raise HTTPException(400, "Password policy: " + " ".join(problems))
        user.password_hash = hash_password(str(payload["new_password"]))
        user.failed_logins = 0
        user.locked_until = None
        changes.append("password=reset")
    db.commit()
    audit(db, admin, "USER_UPDATE", target=user.username, detail="; ".join(changes) or "no changes",
          ip=client_ip(request))
    return user.public()


@app.post("/api/admin/users/{user_id}/password")
def api_admin_reset_password(request: Request, user_id: int, payload: dict,
                             admin: User = Depends(_require_admin),
                             db: DBSession = Depends(get_db)):
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(404, "User not found.")
    new_password = str(payload.get("new_password", ""))
    ok, problems = validate_password(new_password, user.username)
    if not ok:
        raise HTTPException(400, "Password policy: " + " ".join(problems))
    user.password_hash = hash_password(new_password)
    user.failed_logins = 0
    user.locked_until = None
    db.commit()
    audit(db, admin, "USER_PASSWORD_RESET", target=user.username, ip=client_ip(request))
    return {"ok": True}


@app.post("/api/admin/users/{user_id}/unlock")
def api_admin_unlock(user_id: int, admin: User = Depends(_require_admin),
                     db: DBSession = Depends(get_db)):
    target = db.get(User, user_id)
    if target is None:
        raise HTTPException(404, "User not found.")
    target.failed_logins = 0
    target.locked_until = None
    db.commit()
    audit(db, admin, "USER_UNLOCK", target=target.username)
    return {"ok": True}


@app.post("/api/admin/reindex")
def api_admin_reindex(admin: User = Depends(_require_admin), db: DBSession = Depends(get_db)):
    stats = docproc.reindex_all()
    audit(db, admin, "REINDEX", detail=str(stats))
    return {"ok": True, **stats}


@app.get("/api/health")
def health():
    return {"status": "ok", "app": config.APP_NAME, "version": config.VERSION}


# ---------------------------------------------------------------------------
# Error handlers
# ---------------------------------------------------------------------------
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    if request.url.path.startswith("/api"):
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code,
                            headers=getattr(exc, "headers", None))
    return Response(content=f"Error {exc.status_code}: {exc.detail}",
                    status_code=exc.status_code, media_type="text/plain")


@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    if request.url.path.startswith("/api"):
        return JSONResponse({"detail": "Not found."}, status_code=404)
    return HTMLResponse("<h1>404 — Page not found</h1>"
                        "<p><a href='/'>Back to DocuVault Enterprise</a></p>", status_code=404)
