"""
Database layer: SQLAlchemy models, versioned schema migrations, session factory.

Production note: swap the SQLite URL for PostgreSQL (e.g. RDS / Azure Database
/ Cloud SQL). Migrations are tracked in `schema_version`; use Alembic for
larger production schema changes.
"""
from __future__ import annotations

import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, create_engine, inspect, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from . import config

# ---------------------------------------------------------------------------
# Engine / session factory
#   Default: local SQLite file. For Azure / production set DATABASE_URL, e.g.
#     postgresql+psycopg://docvault:PASS@docvault-pg.postgres.database.azure.com:5432/docvault?sslmode=require
#   (Azure Database for PostgreSQL Flexible Server; driver: psycopg[binary])
# ---------------------------------------------------------------------------
_database_url = os.getenv("DATABASE_URL", "").strip()
if _database_url:
    engine = create_engine(_database_url, pool_pre_ping=True)
else:
    engine = create_engine(
        f"sqlite:///{config.DB_PATH}",
        connect_args={"check_same_thread": False},
        pool_pre_ping=True,
    )
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False, autoflush=False)


def utcnow() -> datetime:
    # Naive UTC is used consistently (SQLite drops tzinfo on storage).
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(120), default="")
    email: Mapped[str] = mapped_column(String(190), default="")
    role: Mapped[str] = mapped_column(String(16))            # ADMIN | MANAGER | EMPLOYEE
    clearance: Mapped[int] = mapped_column(Integer)          # 1..4 (derived from role)
    password_hash: Mapped[str] = mapped_column(String(120))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    must_change_password: Mapped[bool] = mapped_column(Boolean, default=False)
    failed_logins: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    # Granular account permissions (admin-managed, enforced server-side):
    can_upload: Mapped[bool] = mapped_column(Boolean, default=True)
    can_ask: Mapped[bool] = mapped_column(Boolean, default=True)
    can_download: Mapped[bool] = mapped_column(Boolean, default=True)
    can_delete_own: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    def public(self) -> dict:
        return {
            "id": self.id,
            "username": self.username,
            "full_name": self.full_name,
            "role": self.role,
            "clearance": self.clearance,
            "clearance_label": config.CLASSIFICATION_LABELS.get(self.clearance, "Internal"),
            "is_admin": self.role == "ADMIN",
            "active": self.is_active,
            "perms": {
                "upload": self.can_upload,
                "ask": self.can_ask,
                "download": self.can_download,
                "delete_own": self.can_delete_own,
            },
        }


class AuthSession(Base):
    """Server-side session store. The cookie/header only carries a random id."""
    __tablename__ = "sessions"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    csrf_token: Mapped[str] = mapped_column(String(64))
    ip_address: Mapped[str] = mapped_column(String(64), default="")
    user_agent: Mapped[str] = mapped_column(String(255), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime)


class Document(Base):
    __tablename__ = "documents"

    id: Mapped[str] = mapped_column(String(32), primary_key=True)   # uuid4 hex
    original_name: Mapped[str] = mapped_column(String(255))
    ext: Mapped[str] = mapped_column(String(12))
    mime: Mapped[str] = mapped_column(String(120), default="application/octet-stream")
    classification: Mapped[int] = mapped_column(Integer)            # 1..4
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    sha256: Mapped[str] = mapped_column(String(64), default="")
    storage_path: Mapped[str] = mapped_column(String(400), default="")
    chunk_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class DocumentBlob(Base):
    """Encrypted document bytes when STORAGE_BACKEND=database."""
    __tablename__ = "document_blobs"

    doc_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    data: Mapped[bytes] = mapped_column(__import__("sqlalchemy").LargeBinary)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    user_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    username: Mapped[str] = mapped_column(String(64), default="")
    action: Mapped[str] = mapped_column(String(40))
    target: Mapped[str] = mapped_column(String(255), default="")
    detail: Mapped[str] = mapped_column(Text, default="")
    ip: Mapped[str] = mapped_column(String(64), default="")


class SchemaVersion(Base):
    __tablename__ = "schema_version"
    version: Mapped[int] = mapped_column(Integer, primary_key=True)


# ---------------------------------------------------------------------------
# Versioned migrations
#   v1 -> base schema (via metadata.create_all)
#   v2 -> example incremental migration (idempotent, pragma-guarded)
# ---------------------------------------------------------------------------
CURRENT_SCHEMA_VERSION = 3


def _column_exists(conn, table: str, column: str) -> bool:
    insp = inspect(conn)
    return column in [c["name"] for c in insp.get_columns(table)]


MIGRATIONS = {
    2: [
        # Example of an incremental, idempotent migration step.
        ("users", "must_change_password", "ALTER TABLE users ADD COLUMN must_change_password BOOLEAN DEFAULT 0"),
    ],
    3: [
        # v3: granular account permissions (user administration feature).
        ("users", "can_upload", "ALTER TABLE users ADD COLUMN can_upload BOOLEAN DEFAULT 1"),
        ("users", "can_ask", "ALTER TABLE users ADD COLUMN can_ask BOOLEAN DEFAULT 1"),
        ("users", "can_download", "ALTER TABLE users ADD COLUMN can_download BOOLEAN DEFAULT 1"),
        ("users", "can_delete_own", "ALTER TABLE users ADD COLUMN can_delete_own BOOLEAN DEFAULT 1"),
    ],
}


def init_db() -> None:
    """Create/upgrade the schema, recording applied migration versions."""
    Base.metadata.create_all(engine)
    with engine.begin() as conn:
        conn.execute(text(
            "CREATE TABLE IF NOT EXISTS schema_version (version INTEGER PRIMARY KEY)"
        ))
        row = conn.execute(text("SELECT MAX(version) FROM schema_version")).first()
        current = (row[0] if row and row[0] is not None else 1)
        for version in range(current + 1, CURRENT_SCHEMA_VERSION + 1):
            steps = MIGRATIONS.get(version, [])
            for table, column, ddl in steps:
                if not _column_exists(conn, table, column):
                    conn.execute(text(ddl))
            conn.execute(text("INSERT OR IGNORE INTO schema_version (version) VALUES (:v)"), {"v": version})


def get_db():
    """FastAPI dependency: one session per request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def new_id() -> str:
    return uuid.uuid4().hex


def audit(db, user: Optional[User], action: str, target: str = "", detail: str = "", ip: str = "") -> None:
    """Append an audit event. Never raises — auditing must not break requests."""
    try:
        db.add(AuditLog(
            user_id=user.id if user else None,
            username=user.username if user else "",
            action=action,
            target=target[:255],
            detail=detail[:2000],
            ip=ip[:64],
        ))
        db.commit()
    except Exception:  # noqa: BLE001
        db.rollback()
