"""
Vector database abstraction.

- ChromaBackend : ChromaDB PersistentClient (preferred; metadata-filtered ANN).
- NumpyBackend  : dependency-free cosine-similarity store (fallback).

Both persist to disk under config.VECTOR_DIR and expose the same interface.
Clearance filtering (`max_clearance`) is enforced *inside the vector query* so
the RAG engine can never retrieve passages above the caller's access level.
"""
from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from . import config


class ChromaBackend:
    name = "ChromaDB"

    def __init__(self, path: Path) -> None:
        import chromadb  # lazy import; optional dependency
        self.space = ""  # space tracked in collection metadata
        self._client = chromadb.PersistentClient(path=str(path))
        self._col = self._client.get_or_create_collection(
            name="docvault",
            metadata={"hnsw:space": "cosine"},
        )
        meta = self._col.metadata or {}
        self.space = meta.get("embedding_space", "")

    def _ensure_space(self, space: str) -> None:
        if self.space != space:
            # only the custom tag may change post-creation (hnsw:space is immutable)
            self._col.modify(metadata={"embedding_space": space})
            self.space = space

    def add(self, ids: List[str], texts: List[str], embeddings: np.ndarray, metadatas: List[dict], space: str) -> None:
        self._ensure_space(space)
        self._col.add(ids=ids, documents=texts, embeddings=embeddings.tolist(), metadatas=metadatas)

    def query(self, embedding: np.ndarray, k: int, max_clearance: int) -> List[dict]:
        if self._col.count() == 0:
            return []
        res = self._col.query(
            query_embeddings=[embedding.tolist()],
            n_results=min(k, self._col.count()),
            where={"classification": {"$lte": max_clearance}},
        )
        hits: List[dict] = []
        docs = res.get("documents") or [[]]
        metas = res.get("metadatas") or [[]]
        dists = res.get("distances") or [[]]
        for i, (text, meta) in enumerate(zip(docs[0], metas[0])):
            sim = 1.0 - float(dists[0][i]) if i < len(dists[0]) else 0.0
            hits.append({"text": text, "metadata": dict(meta), "similarity": sim})
        return hits

    def all_chunks(self, max_clearance: int) -> List[dict]:
        """Every chunk visible at/below the clearance (lexical fallback path)."""
        if self._col.count() == 0:
            return []
        res = self._col.get(include=["documents", "metadatas"],
                            where={"classification": {"$lte": max_clearance}})
        docs = res.get("documents") or []
        metas = res.get("metadatas") or []
        return [{"text": t, "metadata": dict(m)} for t, m in zip(docs, metas)]

    def delete_doc(self, doc_id: str) -> None:
        try:
            self._col.delete(where={"doc_id": doc_id})
        except Exception:  # noqa: BLE001
            pass

    def count(self) -> int:
        return self._col.count()

    def reset(self) -> None:
        self._client.delete_collection("docvault")
        self._col = self._client.get_or_create_collection(
            name="docvault", metadata={"hnsw:space": "cosine"}
        )
        self.space = ""


class NumpyBackend:
    name = "NumPy (built-in fallback)"

    def __init__(self, path: Path) -> None:
        self._lock = threading.Lock()
        self._vectors: Optional[np.ndarray] = None
        self._metas: List[dict] = []
        self._texts: List[str] = []
        self._ids: List[str] = []
        self.space = ""
        self._path = path
        self._load()

    @property
    def _vecfile(self) -> Path:
        return self._path / "vectors.npy"

    @property
    def _metafile(self) -> Path:
        return self._path / "index.json"

    def _load(self) -> None:
        if self._metafile.exists() and self._vecfile.exists():
            try:
                data = json.loads(self._metafile.read_text())
                self.space = data.get("space", "")
                self._metas = data.get("metas", [])
                self._texts = data.get("texts", [])
                self._ids = data.get("ids", [])
                self._vectors = np.load(self._vecfile)
            except Exception:  # noqa: BLE001
                self._vectors, self._metas, self._texts, self._ids, self.space = None, [], [], [], ""

    def _persist(self) -> None:
        config.ensure_dirs()
        np.save(self._vecfile, self._vectors if self._vectors is not None else np.zeros((0, 1), dtype=np.float32))
        self._metafile.write_text(json.dumps({
            "space": self.space, "metas": self._metas, "texts": self._texts, "ids": self._ids,
        }))

    def add(self, ids: List[str], texts: List[str], embeddings: np.ndarray, metadatas: List[dict], space: str) -> None:
        with self._lock:
            if self.space != space:
                self._vectors, self._metas, self._texts, self._ids = None, [], [], []
                self.space = space
            self._ids.extend(ids)
            self._texts.extend(texts)
            self._metas.extend(metadatas)
            self._vectors = embeddings if self._vectors is None or self._vectors.size == 0 \
                else np.vstack([self._vectors, embeddings])
            self._persist()

    def query(self, embedding: np.ndarray, k: int, max_clearance: int) -> List[dict]:
        with self._lock:
            if self._vectors is None or self._vectors.size == 0:
                return []
            mask = np.array([m.get("classification", 4) <= max_clearance for m in self._metas])
            if not mask.any():
                return []
            vecs = self._vectors[mask]
            vn = vecs / (np.linalg.norm(vecs, axis=1, keepdims=True) + 1e-9)
            q = embedding / (np.linalg.norm(embedding) + 1e-9)
            sims = vn @ q
            order = np.argsort(-sims)[:k]
            idxs = np.flatnonzero(mask)[order]
            return [{"text": self._texts[i], "metadata": dict(self._metas[i]),
                     "similarity": float(sims[i])} for i in idxs]

    def all_chunks(self, max_clearance: int) -> List[dict]:
        """Every chunk visible at/below the clearance (lexical fallback path)."""
        with self._lock:
            if self._vectors is None:
                return []
            return [{"text": t, "metadata": dict(m)}
                    for t, m in zip(self._texts, self._metas)
                    if m.get("classification", 4) <= max_clearance]

    def delete_doc(self, doc_id: str) -> None:
        with self._lock:
            keep = [i for i, m in enumerate(self._metas) if m.get("doc_id") != doc_id]
            if len(keep) != len(self._metas):
                self._metas = [self._metas[i] for i in keep]
                self._texts = [self._texts[i] for i in keep]
                self._ids = [self._ids[i] for i in keep]
                self._vectors = self._vectors[keep] if self._vectors is not None and len(keep) else None
                self._persist()

    def count(self) -> int:
        return 0 if self._vectors is None else int(self._vectors.shape[0])

    def reset(self) -> None:
        with self._lock:
            self._vectors, self._metas, self._texts, self._ids, self.space = None, [], [], [], ""
            self._persist()


_store = None


def get_store():
    """Singleton vector store: prefer ChromaDB, fall back to NumPy backend."""
    global _store
    if _store is None:
        config.ensure_dirs()
        try:
            _store = ChromaBackend(config.VECTOR_DIR)
        except Exception:  # noqa: BLE001  — chromadb missing or failed to init
            _store = NumpyBackend(config.VECTOR_DIR)
    return _store
