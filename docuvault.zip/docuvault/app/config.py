"""
Central configuration for DocuVault Enterprise.

All environment-driven settings live here. In production, secrets are injected
via a secrets manager (AWS Secrets Manager / Azure Key Vault / GCP Secret
Manager) and never committed to source control.
"""
import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent


def _load_dotenv() -> None:
    """Minimal .env loader (no extra dependency). Real environment variables win."""
    env_path = BASE_DIR / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key, val = key.strip(), val.strip().strip('"').strip("'")
        if key:
            os.environ.setdefault(key, val)


_load_dotenv()

DATA_DIR = Path(os.getenv("DV_DATA_DIR", str(BASE_DIR / "data")))
ENCRYPTED_DIR = DATA_DIR / "encrypted"          # encrypted documents at rest
DB_PATH = DATA_DIR / "docvault.db"              # SQLite (PostgreSQL in prod)
VECTOR_DIR = DATA_DIR / "vector_index"          # ChromaDB / NumPy index
MASTER_KEY_PATH = DATA_DIR / "master.key"       # root key for doc encryption

# ---------------------------------------------------------------------------
# Branding
# ---------------------------------------------------------------------------
APP_NAME = "DocuVault Enterprise"
VERSION = "2.4.1"
ORG_NAME = "Meridian Systems (Pvt) Ltd."

# ---------------------------------------------------------------------------
# Sessions & authentication hardening
# ---------------------------------------------------------------------------
SESSION_COOKIE = "dvsid"
SESSION_TTL_MINUTES = 30            # sliding idle timeout for authed users
ANON_SESSION_TTL_MINUTES = 60       # pre-login (CSRF) session lifetime
BCRYPT_ROUNDS = 12
MAX_FAILED_LOGINS = 5               # account lockout threshold
LOCKOUT_MINUTES = 15
RATE_LIMIT_ASK_PER_MIN = 15         # per-user AI query rate limit

# ---------------------------------------------------------------------------
# Application firewall (app/firewall.py) — per-IP limits & auto-ban
# ---------------------------------------------------------------------------
RATE_LIMIT_PER_IP_PER_MIN = 240        # all requests / IP
LOGIN_RATE_LIMIT_PER_IP_PER_MIN = 10   # login attempts / IP (brute force)
ASK_RATE_LIMIT_PER_IP_PER_MIN = 60     # AI queries / IP (per-user limit also applies)
UPLOAD_RATE_LIMIT_PER_IP_PER_MIN = 20  # uploads / IP
WAF_VIOLATIONS_TO_BAN = 8              # malicious requests within window -> ban
WAF_VIOLATION_WINDOW_S = 600
WAF_BAN_SECONDS = 900                  # 15-minute automatic IP ban
# Trust X-Forwarded-For only when actually behind a reverse proxy/CDN that
# overwrites it. Direct deployments (and this sandbox) MUST leave it off:
# an attacker can otherwise spoof new IPs per request and evade IP bans.
TRUST_PROXY_XFF = os.getenv("TRUST_PROXY_XFF", "0") == "1"
RATE_LIMIT_ESCALATION_BAN = 3          # 429s within a minute -> short ban
RATE_LIMIT_ESCALATION_SECONDS = 300

# ---------------------------------------------------------------------------
# Document storage backend
#   "local"    — encrypted blobs on local disk (data/encrypted/)
#   "database" — encrypted blobs inside the SQL database (document_blobs table);
#                on Azure the DB is persistent, so a fresh container self-heals:
#                metadata + files come from PostgreSQL and the vector index is
#                automatically re-embedded on first boot.
# ---------------------------------------------------------------------------
STORAGE_BACKEND = os.getenv("STORAGE_BACKEND", "local").strip().lower()
if STORAGE_BACKEND not in ("local", "database"):
    STORAGE_BACKEND = "local"

# ---------------------------------------------------------------------------
# Uploads
# ---------------------------------------------------------------------------
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "100"))
ALLOWED_EXTENSIONS = {".txt", ".md", ".csv", ".json", ".pdf", ".docx"}
# Large files are fully STORED (encrypted), but only the first N chunks are
# embedded for AI search. Keeps indexing time and Gemini quota bounded —
# 600 chunks ≈ 450 KB of text (a long novel). Configurable via env var.
MAX_CHUNKS_PER_DOC = int(os.getenv("MAX_CHUNKS_PER_DOC", "600"))

# ---------------------------------------------------------------------------
# RBAC — role -> maximum clearance level
#   1 Public | 2 Internal | 3 Confidential | 4 Restricted
# ---------------------------------------------------------------------------
ROLES = {"ADMIN": 4, "MANAGER": 3, "EMPLOYEE": 2}
CLASSIFICATION_LABELS = {1: "Public", 2: "Internal", 3: "Confidential", 4: "Restricted"}

# ---------------------------------------------------------------------------
# Gemini API (optional — falls back to Local Retrieval Mode without a key)
# ---------------------------------------------------------------------------
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_CHAT_MODEL = os.getenv("GEMINI_CHAT_MODEL", "gemini-3.6-flash")
GEMINI_EMBED_MODEL = os.getenv("GEMINI_EMBED_MODEL", "gemini-embedding-001")
GEMINI_EMBED_DIM = int(os.getenv("GEMINI_EMBED_DIM", "768"))
# Answering policy:
#   "hybrid"  — document questions answered from the vault with citations;
#               general-knowledge questions answered from Gemini's own knowledge
#               (labelled). Internal-material questions with no matching visible
#               document are STILL refused, so RBAC demos stay intact.
#   "grounded" — strict RAG: never answer outside the vault (pentest mode).
ANSWER_MODE = os.getenv("ANSWER_MODE", "hybrid").strip().lower()
if ANSWER_MODE not in ("hybrid", "grounded"):
    ANSWER_MODE = "hybrid"

# ---------------------------------------------------------------------------
# RAG pipeline tuning
# ---------------------------------------------------------------------------
CHUNK_SIZE = 900            # characters per chunk
CHUNK_OVERLAP = 150         # character overlap between chunks
RETRIEVAL_TOP_K = 8         # candidate chunks fetched from the vector store
MAX_CONTEXT_PASSAGES = 5    # deduplicated passages handed to Gemini


def ensure_dirs() -> None:
    for p in (DATA_DIR, ENCRYPTED_DIR, VECTOR_DIR):
        p.mkdir(parents=True, exist_ok=True)
