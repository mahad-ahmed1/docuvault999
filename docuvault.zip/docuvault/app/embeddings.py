"""
Embedding backends.

- GeminiEmbedder  : Google `gemini-embedding-001` via the google-genai SDK
                    (task types RETRIEVAL_DOCUMENT / RETRIEVAL_QUERY).
- LocalEmbedder   : deterministic hashing TF-IDF embedder (no network, no key).
                    Used when GEMINI_API_KEY is not configured so the portal
                    still indexes and retrieves documents offline.

Every embedder exposes a `space` identifier. The vector index records which
space it was built in; if the space changes (e.g. a Gemini key is added), the
index is transparently rebuilt from the encrypted source files.
"""
from __future__ import annotations

import hashlib
import math
import re
import threading
from typing import List

import numpy as np

from . import config

try:  # optional dependency — only needed when GEMINI_API_KEY is set
    from google import genai as _ggenai
    from google.genai import types as _gtypes
    _HAS_GEMINI_SDK = True
except Exception:  # noqa: BLE001
    _HAS_GEMINI_SDK = False

_TOKEN_RE = re.compile(r"[a-z0-9]+")
_STOP = set("the a an and or of to in on for with is are was were be been at as by it "
            "this that these those from not you your we our they their he she his her "
            "will shall may can do does did if then than so such no nor but "
            "what which who whom whose when where why how tell give show please".split())


class LocalEmbedder:
    """Hashed TF-IDF (sublinear TF, 512-dim, L2-normalised) — pure local mode."""
    space = "local-hash-tfidf@512"
    dim = 512
    min_similarity = 0.08  # relevance floor for retrieve()

    def _vec(self, text: str) -> np.ndarray:
        tokens = [t for t in _TOKEN_RE.findall(text.lower()) if t not in _STOP]
        grams = tokens + [f"{a}_{b}" for a, b in zip(tokens, tokens[1:])]
        counts: dict[int, float] = {}
        for g in grams:
            idx = int.from_bytes(hashlib.blake2b(g.encode(), digest_size=8).digest(), "big") % self.dim
            counts[idx] = counts.get(idx, 0.0) + 1.0
        v = np.zeros(self.dim, dtype=np.float32)
        for idx, c in counts.items():
            v[idx] = 1.0 + math.log(c)
        n = float(np.linalg.norm(v))
        return v / n if n > 0 else v

    def embed_documents(self, texts: List[str]) -> np.ndarray:
        return np.stack([self._vec(t) for t in texts])

    def embed_query(self, text: str) -> np.ndarray:
        return self._vec(text)


class GeminiEmbedder:
    """Google Gemini embeddings via google-genai."""

    min_similarity = 0.28  # relevance floor for retrieve() (cosine, normalized 768-d)

    def __init__(self) -> None:
        if not (_HAS_GEMINI_SDK and config.GEMINI_API_KEY):
            raise RuntimeError("Gemini embeddings require GEMINI_API_KEY and the google-genai package.")
        self.space = f"gemini:{config.GEMINI_EMBED_MODEL}@{config.GEMINI_EMBED_DIM}"
        self.dim = config.GEMINI_EMBED_DIM
        self._client = None
        self._lock = threading.Lock()

    @property
    def client(self):
        with self._lock:
            if self._client is None:
                self._client = _ggenai.Client(api_key=config.GEMINI_API_KEY)
            return self._client

    def _embed(self, texts: List[str], task: str) -> np.ndarray:
        import time

        out: List[List[float]] = []
        for i in range(0, len(texts), 90):  # batch size cap
            batch = texts[i:i + 90]
            last_exc: Exception | None = None
            for attempt, delay in enumerate((0, 10, 25)):  # ride out transient quota/503
                if delay:
                    time.sleep(delay)
                try:
                    resp = self.client.models.embed_content(
                        model=config.GEMINI_EMBED_MODEL,
                        contents=batch,
                        config=_gtypes.EmbedContentConfig(task_type=task, output_dimensionality=self.dim),
                    )
                    break
                except Exception as exc:  # noqa: BLE001
                    last_exc = exc
                    s = str(exc)
                    transient = "429" in s or "503" in s or "RESOURCE_EXHAUSTED" in s.upper() \
                        or "UNAVAILABLE" in s.upper()
                    if not transient:
                        raise
            else:
                raise last_exc  # type: ignore[misc] — all attempts transient-failed
            out.extend([list(e.values) for e in resp.embeddings])
        return np.asarray(out, dtype=np.float32)

    def embed_documents(self, texts: List[str]) -> np.ndarray:
        return self._embed(texts, "RETRIEVAL_DOCUMENT")

    def embed_query(self, text: str) -> np.ndarray:
        return self._embed([text], "RETRIEVAL_QUERY")[0]


_embedder = None


def get_embedder():
    """Singleton embedder selection: Gemini when configured, else local."""
    global _embedder
    if _embedder is None:
        if config.GEMINI_API_KEY:
            try:
                _embedder = GeminiEmbedder()
            except Exception:  # noqa: BLE001
                _embedder = LocalEmbedder()
        else:
            _embedder = LocalEmbedder()
    return _embedder
