"""
File storage abstraction for encrypted documents.

  LocalFileStore    — bytes on local disk (data/encrypted/<id>.bin)
  DatabaseFileStore — bytes in the SQL database (document_blobs table);
                      the right choice for Azure/production: PostgreSQL is
                      persistent and backed up, so documents survive restarts,
                      redeploys and scaling without a file-share mount.

The bytes handed to / returned from a store are ALWAYS the encrypted
ciphertext — the master key is never in this layer.
"""
from __future__ import annotations

from pathlib import Path

from . import config


class LocalFileStore:
    name = "local disk (data/encrypted/)"

    def __init__(self) -> None:
        config.ensure_dirs()

    def put(self, doc_id: str, ciphertext: bytes) -> str:
        path = config.ENCRYPTED_DIR / f"{doc_id}.bin"
        path.write_bytes(ciphertext)
        return str(path)

    def get(self, doc_id: str, storage_path: str) -> bytes:
        return Path(storage_path).read_bytes()

    def delete(self, doc_id: str, storage_path: str) -> None:
        Path(storage_path).unlink(missing_ok=True)


class DatabaseFileStore:
    name = "SQL database (document_blobs table)"

    def put(self, doc_id: str, ciphertext: bytes) -> str:
        from .db import DocumentBlob, SessionLocal
        db = SessionLocal()
        try:
            row = db.get(DocumentBlob, doc_id)
            if row is not None:
                row.data = ciphertext
            else:
                db.add(DocumentBlob(doc_id=doc_id, data=ciphertext))
            db.commit()
        finally:
            db.close()
        return f"db:{doc_id}"

    def get(self, doc_id: str, storage_path: str) -> bytes:
        from .db import DocumentBlob, SessionLocal
        db = SessionLocal()
        try:
            row = db.get(DocumentBlob, doc_id)
            if row is None:
                raise FileNotFoundError(f"document blob {doc_id} not found in database")
            return row.data
        finally:
            db.close()

    def delete(self, doc_id: str, storage_path: str) -> None:
        from .db import DocumentBlob, SessionLocal
        db = SessionLocal()
        try:
            row = db.get(DocumentBlob, doc_id)
            if row is not None:
                db.delete(row)
                db.commit()
        finally:
            db.close()

    def get_all_ids(self) -> list[str]:
        from .db import DocumentBlob, SessionLocal
        db = SessionLocal()
        try:
            return [r[0] for r in db.query(DocumentBlob.doc_id).all()]
        finally:
            db.close()


_file_store = None


def get_file_store():
    global _file_store
    if _file_store is None:
        _file_store = DatabaseFileStore() if config.STORAGE_BACKEND == "database" else LocalFileStore()
    return _file_store
