# Deploying DocuVault Enterprise on Azure

Three supported paths, from "demo by tonight" to production-grade. All commands use the
Azure CLI (`az`) — install with `pip install azure-cli` and run `az login` first.

| | Option 1 — App Service | Option 2 — Container Apps (recommended) | Option 3 — VM |
|---|---|---|---|
| Effort | ~15 minutes | ~1 hour | ~1 hour |
| Cost | B1 ≈ $13/mo | ≈ $20–40/mo (CA + Postgres + Files) | B2s ≈ $30/mo |
| Database | SQLite on `/home` (single instance) | **Azure Database for PostgreSQL** | your choice |
| Best for | Class demo, proof of concept | Real deployment, the pentest | Full control / learning |
| TLS + domain | Free `*.azurewebsites.net` cert, HTTPS toggle | Free managed cert via Front Door/App Env | you manage |

---

## Before you deploy (both options)

1. **Generate a master key** for document encryption (or the app makes one on first boot):

   ```bash
   python3 -c "import base64,secrets; print(base64.urlsafe_b64encode(secrets.token_bytes(32)).decode())"
   ```

2. **Production environment settings** (used in every option below):

   | Setting | Value | Why |
   |---|---|---|
   | `GEMINI_API_KEY` | your key | AI generation (or leave unset → Local Retrieval Mode) |
   | `MASTER_KEY` | generated base64 key | stable document-encryption key across restarts/redeploys |
   | `ADMIN_USERNAME` / `ADMIN_PASSWORD` | your values | bootstrap admin (policy-checked) |
   | `DV_DATA_DIR` | `/home/data` (App Service) or `/data` (container+volume) | persistent storage location (not needed for documents when `STORAGE_BACKEND=database`) |
  | `STORAGE_BACKEND` | `database` | store encrypted document bytes in PostgreSQL (survive redeploys; no file mount required) |
   | `DATABASE_URL` | `postgresql+psycopg://...?sslmode=require` | only when using Azure PostgreSQL (Option 2) |

3. **Code readiness already built in:** `/api/health` probe endpoint, `X-Forwarded-For` /
   `X-Forwarded-Proto` trust (correct client IPs + automatic `Secure` cookies behind TLS),
   `DATABASE_URL` override, **`STORAGE_BACKEND=database`** (encrypted document bytes stored in
   the SQL database — everything persistent with zero file mounts), Dockerfile, `.dockerignore`.

### Where your documents live

| `STORAGE_BACKEND` | Document bytes | After a restart/redeploy |
|---|---|---|
| `local` (default) | disk (`data/encrypted/`) — needs the Azure Files mount | persist only with the mounted share |
| **`database`** (recommended for Azure) | **inside PostgreSQL** (`document_blobs`, AES+HMAC-encrypted) | **fully persistent**; the vector index auto-rebuilds itself from the DB on first boot |

With `STORAGE_BACKEND=database` + `DATABASE_URL`, a brand-new container boots, finds the
documents in the database, and re-embeds the search index automatically — no file share, no
manual steps. (One-time cost: re-embedding consumes Gemini quota on first boot.)

---

## Option 1 — Azure App Service (fastest)

SQLite lives on the persistent `/home` share; fine for a single-instance demo.

```bash
RG=docvault-rg; LOC=centralindia; APP=docvault-$RANDOM        # LOC: centralindia/uaenorth are closest to Pakistan
az group create -n $RG -l $LOC

az appservice plan create -g $RG -n docvault-plan --is-linux --sku B1
az webapp create -g $RG -n $APP --plan docvault-plan --runtime "PYTHON:3.13"

# deploy the code (zip)
cd docuvault && zip -r ../docuvault.zip . -x "data/*" -x ".venv/*" -x "__pycache__/*" && cd ..
az webapp deploy -g $RG -n $APP --src-path docuvault.zip --type zip

# configuration
az webapp config appsettings set -g $RG -n $APP --settings \
  DV_DATA_DIR=/home/data SCM_DO_BUILD_DURING_DEPLOYMENT=true \
  GEMINI_API_KEY="<your-key>" MASTER_KEY="<generated-key>" \
  ADMIN_USERNAME="admin" ADMIN_PASSWORD="<strong password>"

# FastAPI startup: gunicorn with uvicorn workers (gunicorn is in requirements.txt)
az webapp config set -g $RG -n $APP \
  --startup-file "gunicorn -w 2 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000 app.main:app"

# force HTTPS (free managed certificate on *.azurewebsites.net is automatic)
az webapp update -g $RG -n $APP --https-only true
az webapp log tail -g $RG -n $APP        # watch startup: "[startup] DocuVault ... ready"
```

Open `https://$APP.azurewebsites.net`. First boot bootstraps the administrator account only —
the vault starts empty; create users under **User Administration** and upload real documents.

**Limits of Option 1:** SQLite + in-memory firewall/session/limiter state assume one worker
instance — do not scale out beyond 1. Graduate to Option 2 when you need that.

### CI/CD (optional, works for both options)

`.github/workflows/deploy.yml`:

```yaml
on: { push: { branches: [main] } }
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: azure/login@v2
        with: { creds: "${{ secrets.AZURE_CREDENTIALS }}" }
      - uses: azure/webapps-deploy@v3
        with: { app-name: docvault-APPNAME, package: . }
```

---

## Option 2 — Container Apps + PostgreSQL (recommended production shape)

```bash
RG=docvault-rg; LOC=centralindia; ACR=docvaultreg$RANDOM; ENV=docvault-env; APP=docvault

# 1) registry + image
az acr create -g $RG -n $ACR --sku Basic
az acr build -r $ACR -t docuvault:v1 .                       # run from the docuvault/ folder

# 2) Azure Database for PostgreSQL Flexible Server
az postgres flexible-server create -g $RG -n docvault-pg \
  --location $LOC --tier Burstable --sku-name Standard_B1ms \
  --version 16 --storage-size 32 --high-availability Disabled \
  --admin-user docvault --admin-password "<strong password>"
az postgres flexible-server db create -g $RG -s docvault-pg -d docvault
az postgres flexible-server firewall-rule create -g $RG -s docvault-pg -n allow-azure --start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0

# 3) persistent file storage for encrypted docs + vector index (Azure Files)
SA=docvaultdata$RANDOM
az storage account create -g $RG -n $SA --sku Standard_LRS
az storage share create --account-name $SA --name docvaultdata --quota 5

# 4) Container Apps environment + app
az containerapp env create -g $RG -n $ENV -l $LOC
PGHOST=$(az postgres flexible-server list -g $RG --query "[0].fullyQualifiedDomainName" -o tsv)
az containerapp create -g $RG -n $APP --environment $ENV \
  --image $ACR.azurecr.io/docuvault:v1 \
  --registry-server $ACR.azurecr.io \
  --target-port 8080 --ingress external \
  --min-replicas 1 --max-replicas 3 \
  --secrets pg-conn="postgresql+psycopg://docvault:<pw>@$PGHOST:5432/docvault?sslmode=require" \
  --env-vars DATABASE_URL=secretref:pg-conn STORAGE_BACKEND=database \
             MASTER_KEY="<generated-key>" GEMINI_API_KEY="<key>" DV_DATA_DIR=/data
# That's it: with STORAGE_BACKEND=database the documents live in PostgreSQL —
# persistent across redeploys and replicas. The Azure Files mount (guide below)
# is now optional (only useful if you prefer file storage for very large PDFs).
```

### Hardening layer (do these before the pentest in prod)

- **Azure Key Vault + managed identity:** store `MASTER_KEY`, `GEMINI_API_KEY`, `pg-conn` as
  Key Vault secrets and reference them (`secretref:`) instead of literals; grant the app's
  managed identity `get` on the vault. Nothing secret ends up in ARM/env dumps.
- **Azure Front Door Premium + WAF:** put the WAF (managed OWASP 3.2 rule set + bot
  protection + custom rate-limit rule, e.g. 100 req/min/IP) in front of the app; this is the
  network-edge complement to the in-app firewall and absorbs volumetric DDoS. Lock the
  Container App ingress to Front Door's backend.
- **Azure Cache for Redis:** back sessions, rate-limit windows, bans and the answer cache
  (port `firewall.py` counters + the session store to Redis) so multi-replica scaling and
  restarts keep state. Roadmap item in the code; single-replica works without it.
- **PostgreSQL is already wired:** just set `DATABASE_URL` (done above). The schema
  auto-creates on first boot; take `az postgres flexible-server backup` defaults + geo-redundancy.
- **Monitor:** `az monitor app-insights component create` → wire the connection string;
  enable Defender for Cloud on the subscription; audit-log table can be shipped to Log
  Analytics via diagnostics.
- **Frontend toggles for production** (one-line edits in `app/main.py`): restrict CORS
  `allow_origin_regex` to your real domain, set `frame-ancestors 'self'` in the CSP header.

---

## Option 3 — Azure VM (simplest mental model)

```bash
az vm create -g docvault-rg -n docvault-vm --image Ubuntu2204 --size Standard_B2s \
  --admin-azure-login-username azureuser --generate-ssh-keys --public-ip-sku Standard
az vm open-port -g docvault-rg -n docvault-vm --port 80,443
# ssh in, clone/copy the repo, then:
sudo apt update && sudo apt install -y python3-pip nginx
sudo ufw allow 22,80,443 && sudo ufw enable          # host firewall (nftables) — closes every port except what you need
pip install -r requirements.txt
# systemd unit runs: python3 -m uvicorn app.main:app --host 127.0.0.1 --port 8080
# nginx as reverse proxy with certbot TLS → proxy_pass http://127.0.0.1:8080
```

Point a DNS A-record at the VM IP, run `certbot --nginx`, done. The app reads
`X-Forwarded-For`/`X-Forwarded-Proto` from nginx automatically.

---

## Post-deployment checklist

- [ ] `https://<app>/api/health` returns `{"status": "ok"}` over **HTTPS only**
- [ ] `ADMIN_PASSWORD` is a strong unique secret; the documented bootstrap default was changed after first login
- [ ] `MASTER_KEY` set from Key Vault (documents decrypt correctly after a restart)
- [ ] Cookies carry `Secure` (check in browser devtools — automatic behind TLS via `X-Forwarded-Proto`)
- [ ] Login lockout + WAF ban tested from your IP (see PENTEST_BRIEF §5 probes)
- [ ] `/api/admin/overview` → Security panel shows the firewall counting
- [ ] CORS + CSP tightened for the real domain (two one-line edits in `app/main.py`)
- [ ] Backups: Postgres automatic backups on (with `STORAGE_BACKEND=database` this backs up the documents too); Key Vault secrets pinned
- [ ] Defender for Cloud recommendations clear; App Insights receiving requests

## Rough monthly cost (single-region, minimal)

| Item | SKU | ≈ $/mo |
|---|---|---|
| App Service (Option 1) | B1 | 13 |
| Container Apps (Option 2) | Consumption | 5–15 |
| PostgreSQL Flexible | B1ms | 13 |
| Azure Files 5 GB | Standard_LRS | ~1 |
| Key Vault + Front Door Premium | — | 0.03 + ~40 (FD only if you want the premium WAF; skip at demo scale) |
