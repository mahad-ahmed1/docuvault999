#!/usr/bin/env bash
# DocuVault Enterprise — launcher
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
  echo "[run.sh] creating virtual environment..."
  python3 -m venv .venv
  ./.venv/bin/pip install --quiet -r requirements.txt
fi

echo "[run.sh] starting DocuVault Enterprise on http://0.0.0.0:8080"
exec ./.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8080}"
